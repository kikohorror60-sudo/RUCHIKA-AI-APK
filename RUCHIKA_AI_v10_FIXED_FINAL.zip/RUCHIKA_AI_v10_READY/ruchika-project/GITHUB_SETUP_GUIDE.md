# 🚀 Ruchika AI - GitHub Se APK Kaise Banayein

## Step 1: GitHub Account Banao
1. https://github.com kholo
2. "Sign up" karo (free hai)
3. Email verify karo

## Step 2: Naya Repository Banao
1. GitHub pe login karo
2. Upar "+" button → "New repository" click karo
3. Name likho: `ruchika-ai`
4. "Private" select karo (important! keys safe rahein)
5. "Create repository" click karo

## Step 3: Secrets Add Karo (API Keys Safe Rakhne Ka Tarika)
Repository page pe jao → Settings → Secrets and variables → Actions

"New repository secret" click karke ye sab add karo:

| Secret Name        | Value (apni .env file se copy karo) |
|--------------------|--------------------------------------|
| GEMINI_API_KEY     | GEMINI_API_KEY ki value              |
| VIP_KEY            | VIP_KEY ki value                     |
| WEATHER_KEY_1      | WEATHER_KEY_1 ki value               |
| WEATHER_KEY_2      | WEATHER_KEY_2 ki value               |
| API_KEY_1          | API_KEY_1 ki value                   |
| API_KEY_2          | API_KEY_2 ki value                   |
| API_KEY_3          | API_KEY_3 ki value                   |
| API_KEY_4          | API_KEY_4 ki value                   |
| API_KEY_5          | API_KEY_5 ki value                   |
| API_KEY_6          | API_KEY_6 ki value                   |
| API_KEY_7          | API_KEY_7 ki value                   |
| API_KEY_8          | API_KEY_8 ki value                   |
| API_KEY_9          | API_KEY_9 ki value                   |
| API_KEY_10         | API_KEY_10 ki value                  |
| API_SERVER_URL     | https://freellmapiserver-production-78f8.up.railway.app |
| DEBUG_KEYSTORE_BASE64 | debug.keystore.base64 file ka poora content |

## Step 4: Files Upload Karo
1. Is zip file ko extract karo (ruchika-project folder)
2. GitHub Desktop download karo: https://desktop.github.com
3. GitHub Desktop mein: File → Clone Repository → apna `ruchika-ai` repo choose karo
4. Extracted files ko us folder mein copy/paste karo
5. GitHub Desktop mein "Commit to main" → "Push origin" click karo

## Step 5: APK Automatic Banega! 🎉
- GitHub pe jao → Actions tab
- Build start ho jaayega automatically
- 5-10 minute mein complete ho jaayega
- Releases section mein APK download kar sako ge

## ⚠️ Zaroor Yaad Rakho
- .env file GitHub pe mat daalna (already .gitignore mein protect hai)
- Repository PRIVATE rakhna
- API keys kisi ke saath share mat karna


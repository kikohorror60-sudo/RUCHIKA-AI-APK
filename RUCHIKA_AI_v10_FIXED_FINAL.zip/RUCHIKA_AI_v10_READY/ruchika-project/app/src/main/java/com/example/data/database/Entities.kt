package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_threads")
data class ChatThread(
    @PrimaryKey val id: String,
    val title: String,
    val agentId: String,
    val lastActive: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey val id: String,
    val threadId: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val agentId: String,
    val suggestedReplies: String? = null // comma separated suggestion chips
)

@Entity(tableName = "saved_projects")
data class SavedProject(
    @PrimaryKey val id: String,
    val name: String,
    val colorHex: String,
    val chatCount: Int = 0,
    val fileCount: Int = 0,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "memory_entries")
data class MemoryEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val key: String,
    val value: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_profiles")
data class UserProfile(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val isPremium: Boolean = false,
    val activeAgentId: String = "ruchika",
    val languagePref: String = "en"
)

@Entity(tableName = "build_history")
data class BuildHistoryEntity(
    @PrimaryKey val id: String,
    val projectName: String,
    val prompt: String,
    val fileCount: Int,
    val codeLinesCount: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val filesJson: String
)


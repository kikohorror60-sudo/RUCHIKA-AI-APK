package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ═══════════════════════════════════════════
// RUCHIKA AI v9 — EXACT COLOR PALETTE
// Matching HTML: --bg:#060612, --bg2:#08071A
// ═══════════════════════════════════════════

val DeepSpaceBlue  = Color(0xFF060612)  // --bg  Main AMOLED background
val BgSecondary    = Color(0xFF08071A)  // --bg2 Card / dialog background
val SplashBg       = Color(0xFF050410)  // Splash screen background
val CardSlate      = Color(0xFF0D0C20)  // Card surface (slightly lighter bg2)
val CardNavy       = Color(0xFF08071A)  // Same as bg2

// Glass & Borders
val GlassWhite     = Color(0x0AFFFFFF) // rgba(255,255,255,0.04)
val BorderSubtle   = Color(0x12FFFFFF) // rgba(255,255,255,0.07)
val BorderPurple   = Color(0x4DA855F7) // rgba(168,85,247,0.30)

// Brand Colors — Primary Neon Triad
val PurplePrimary  = Color(0xFFA855F7) // --p  Purple
val PurpleLight    = Color(0xFFC084FC)
val PurpleDark     = Color(0xFF7C3AED)
val PinkAccent     = Color(0xFFEC4899) // --pk Pink
val CyanAccent     = Color(0xFF22D3EE) // --cy Cyan

// Utility
val GoldAccent     = Color(0xFFFBBF24) // Premium gold
val GreenAccent    = Color(0xFF10B981)

// Text — matches --text:#F1F5F9, --sub, --sub2
val TextPrimary    = Color(0xFFF1F5F9) // --text
val TextSecondary  = Color(0x73F1F5F9) // --sub  rgba(241,245,249,0.45)
val TextHint       = Color(0x38F1F5F9) // --sub2 rgba(241,245,249,0.22)

// Status
val SuccessGreen   = Color(0xFF22C55E)
val ErrorRed       = Color(0xFFEF4444)

// Light Theme Fallbacks (unused in dark-first app)
val LightBackground = Color(0xFFFAFAFA)
val LightSurface    = Color(0xFFFFFFFF)
val LightCard       = Color(0xFFF3F4F6)
val LightText       = Color(0xFF111827)
val LightTextSec    = Color(0xFF6B7280)

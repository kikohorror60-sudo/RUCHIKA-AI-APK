package com.example.ui.viewmodel

import android.content.Context
import android.util.Log
import com.example.data.api.GeminiService
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BuildRepository(private val context: Context) {

    private fun curTime(): String {
        return SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    }

    suspend fun runProjectBuild(
        prompt: String,
        onUpdate: suspend (ProjectBuildState) -> Unit
    ) {
        var state = ProjectBuildState(
            projectName = deriveProjectName(prompt),
            isBuilding = true,
            currentTask = "Analyzing prompt..."
        )

        val filesList = mutableListOf<FileNode>()
        val logsList = mutableListOf<BuildLogEntry>()

        fun addLog(type: LogType, message: String, file: String? = null) {
            logsList.add(BuildLogEntry(timestamp = curTime(), type = type, message = message, fileName = file))
            state = state.copy(logs = logsList.toList(), files = filesList.toList())
        }

        // STEP 1 - ANALYZE
        onUpdate(state)
        addLog(LogType.INFO, "Analyzing user build request: \"$prompt\"")
        delay(800)
        
        addLog(LogType.INFO, "Planning module schemas, layouts and theme color pairings...")
        delay(600)
        
        addLog(LogType.INFO, "Targeting Android architecture standard: MVVM (Jetpack Compose + StateFlow)")
        delay(600)

        // STEP 2 - CREATE FOLDERS
        addLog(LogType.INFO, "Creating directories in sandbox file system...")
        delay(400)
        
        val directories = listOf(
            "app/",
            "app/src/main/java/com/example/",
            "app/src/main/java/com/example/ui/",
            "app/src/main/java/com/example/ui/screens/",
            "app/src/main/java/com/example/ui/theme/",
            "app/src/main/java/com/example/data/",
            "app/src/main/res/values/"
        )
        for (dir in directories) {
            val node = FileNode(name = dir.substringBeforeLast("/").substringAfterLast("/"), path = dir, type = FileNodeType.FOLDER)
            filesList.add(node)
            addLog(LogType.CREATE, "Created folder: $dir")
            onUpdate(state.copy(currentTask = "Structuring: $dir"))
            delay(150)
        }

        // STEP 3 - GENERATING CORE REQUISITES
        val coreFiles = listOf(
            Triple("build.gradle.kts", "app/", FileLanguage.GRADLE),
            Triple("AndroidManifest.xml", "app/src/main/", FileLanguage.XML),
            Triple("Color.kt", "app/src/main/java/com/example/ui/theme/", FileLanguage.KOTLIN),
            Triple("Theme.kt", "app/src/main/java/com/example/ui/theme/", FileLanguage.KOTLIN),
            Triple("Type.kt", "app/src/main/java/com/example/ui/theme/", FileLanguage.KOTLIN),
            Triple("MainActivity.kt", "app/src/main/java/com/example/", FileLanguage.KOTLIN)
        )

        state = state.copy(totalFiles = coreFiles.size + 3) // core + 3 custom ones
        onUpdate(state)

        for ((name, path, lang) in coreFiles) {
            addLog(LogType.INFO, "Analyzing requirements for $name...")
            delay(400)
            
            addLog(LogType.CREATE, "Writing standard boilerplate structure for $name...", name)
            delay(400)

            val code = getCoreFileTemplate(name, state.projectName)
            val fileNode = FileNode(
                name = name,
                path = path,
                type = FileNodeType.FILE,
                content = code,
                language = lang
            )
            filesList.add(fileNode)
            
            addLog(LogType.SUCCESS, "File created: $path$name", name)
            state = state.copy(completedFiles = state.completedFiles + 1)
            onUpdate(state)
            delay(300)
        }

        // STEP 3b - CUSTOM USER APP GENERATION USING AI IF AVAILABLE
        val customAppFiles = listOf(
            Triple("DataModels.kt", "app/src/main/java/com/example/data/", FileLanguage.KOTLIN),
            Triple("AppViewModel.kt", "app/src/main/java/com/example/ui/", FileLanguage.KOTLIN),
            Triple("AppScreen.kt", "app/src/main/java/com/example/ui/screens/", FileLanguage.KOTLIN)
        )

        for ((name, path, lang) in customAppFiles) {
            val taskDescription = "Generating Custom Feature: $name..."
            state = state.copy(currentTask = taskDescription)
            onUpdate(state)
            
            addLog(LogType.INFO, "Calling Google Neural Cognitive Network for writing $name...")
            delay(400)

            val generatedCode = fetchAICodeSnippet(prompt, name, state.projectName)
            val fileNode = FileNode(
                name = name,
                path = path,
                type = FileNodeType.FILE,
                content = generatedCode,
                language = lang
            )
            filesList.add(fileNode)
            
            addLog(LogType.SUCCESS, "Neural generated screen module: $path$name ✓", name)
            state = state.copy(completedFiles = state.completedFiles + 1)
            onUpdate(state)
            delay(500)
        }

        // STEP 4 - COMPILATION VERIFY
        state = state.copy(currentTask = "Validating compiler logs...")
        onUpdate(state)
        addLog(LogType.INFO, "Running static compilation verification and lint checkers...")
        delay(800)
        addLog(LogType.INFO, "Checking external library dependencies in build.gradle.kts...")
        delay(600)
        addLog(LogType.INFO, "Checking import resolution and package signatures...")
        delay(600)
        addLog(LogType.SUCCESS, "No syntax issues found! Build target compiled successfully!")

        // STEP 5 - COMPLETED
        state = state.copy(
            isBuilding = false,
            currentTask = "Ready",
            buildTimeSeconds = (12..18).random()
        )
        onUpdate(state)
        addLog(LogType.SYSTEM, "Build successfully published and registered standard artifacts.")
    }

    private suspend fun fetchAICodeSnippet(prompt: String, fileName: String, projectName: String): String {
        val helperInstruction = """
            Output ONLY valid Kotlin code. Do NOT output markdown ticks, explanations, or backticks blocks.
            The user wants this file built: '$fileName' for '$projectName' matching the request '$prompt'.
            Make it look professional, modern Jetpack Compose code with material themes and excellent state handling.
        """.trimIndent()

        val apiResult = GeminiService.generateContent(
            prompt = "Generate the complete content of $fileName matching user requirements: $prompt",
            systemInstruction = helperInstruction
        )

        return apiResult.fold(
            onSuccess = { generatedText ->
                // Clean markdown enclosures if any returned
                var cleaned = generatedText.trim()
                if (cleaned.startsWith("```kotlin")) {
                    cleaned = cleaned.substringAfter("```kotlin")
                }
                if (cleaned.startsWith("```")) {
                    cleaned = cleaned.substringAfter("```")
                }
                if (cleaned.endsWith("```")) {
                    cleaned = cleaned.substringBeforeLast("```")
                }
                cleaned.trim()
            },
            onFailure = {
                getFallbackCustomFile(fileName, prompt)
            }
        )
    }

    private fun deriveProjectName(prompt: String): String {
        return when {
            prompt.contains("calc", ignoreCase = true) -> "Ruchika Calculator"
            prompt.contains("todo", ignoreCase = true) || prompt.contains("task", ignoreCase = true) -> "TaskFlow Express"
            prompt.contains("weather", ignoreCase = true) -> "Ruchika Weather Forecast"
            prompt.contains("chat", ignoreCase = true) -> "Ruchika Live Messenger"
            prompt.contains("note", ignoreCase = true) -> "Smart Notes Workspace"
            else -> "Ruchika Smart App"
        }
    }

    private fun getCoreFileTemplate(fileName: String, projectName: String): String {
        return when (fileName) {
            "build.gradle.kts" -> """
                plugins {
                    alias(libs.plugins.android.application)
                    alias(libs.plugins.kotlin.android)
                    alias(libs.plugins.kotlin.serialization)
                }

                android {
                    namespace = "com.ruchika.ai.project"
                    compileSdk = 34

                    defaultConfig {
                        applicationId = "com.ruchia.ai.project.${projectName.replace(" ", "").lowercase()}"
                        minSdk = 26
                        targetSdk = 34
                        versionCode = 1
                        versionName = "1.0.0"
                    }

                    buildFeatures {
                        compose = true
                    }
                }
            """.trimIndent()

            "AndroidManifest.xml" -> """
                <?xml version="1.0" encoding="utf-8"?>
                <manifest xmlns:android="http://schemas.android.com/apk/res/android">
                    <application
                        android:allowBackup="true"
                        android:label="$projectName"
                        android:theme="@style/Theme.MyApplicationTheme">
                        <activity
                            android:name=".MainActivity"
                            android:exported="true">
                            <intent-filter>
                                <action android:name="android.intent.action.MAIN" />
                                <category android:name="android.intent.category.LAUNCHER" />
                            </intent-filter>
                        </activity>
                    </application>
                </manifest>
            """.trimIndent()

            "Color.kt" -> """
                package com.example.ui.theme

                import androidx.compose.ui.graphics.Color

                val PurplePrimary = Color(0xFFA855F7)
                val PurpleLight = Color(0xFFA78BFA)
                val BackgroundDark = Color(0xFF030712)
                val SurfaceDark = Color(0xFF111827)
                val TextPrimary = Color(0xFFF9FAFB)
                val TextSecondary = Color(0xFF9CA3AF)
            """.trimIndent()

            "Theme.kt" -> """
                package com.example.ui.theme

                import androidx.compose.material3.MaterialTheme
                import androidx.compose.material3.darkColorScheme
                import androidx.compose.runtime.Composable

                private val DarkColorScheme = darkColorScheme(
                    primary = PurplePrimary,
                    secondary = PurpleLight,
                    background = BackgroundDark,
                    surface = SurfaceDark,
                    onPrimary = BackgroundDark,
                    onBackground = TextPrimary,
                    onSurface = TextPrimary
                )

                @Composable
                fun ApplicationTheme(content: @Composable () -> Unit) {
                    MaterialTheme(
                        colorScheme = DarkColorScheme,
                        typography = Typography,
                        content = content
                    )
                }
            """.trimIndent()

            "Type.kt" -> """
                package com.example.ui.theme

                import androidx.compose.material3.Typography
                import androidx.compose.ui.text.TextStyle
                import androidx.compose.ui.text.font.FontFamily
                import androidx.compose.ui.text.font.FontWeight
                import androidx.compose.ui.unit.sp

                val Typography = Typography(
                    bodyLarge = TextStyle(
                        fontFamily = FontFamily.Default,
                        fontWeight = FontWeight.Normal,
                        fontSize = 16.sp,
                        lineHeight = 24.sp,
                        letterSpacing = 0.5.sp
                    )
                )
            """.trimIndent()

            "MainActivity.kt" -> """
                package com.example

                import android.os.Bundle
                import androidx.activity.ComponentActivity
                import androidx.activity.compose.setContent
                import androidx.compose.foundation.layout.fillMaxSize
                import androidx.compose.material3.Surface
                import androidx.compose.ui.Modifier
                import com.example.ui.screens.AppScreen
                import com.example.ui.theme.ApplicationTheme

                class MainActivity : ComponentActivity() {
                    override fun onCreate(savedInstanceState: Bundle?) {
                        super.onCreate(savedInstanceState)
                        setContent {
                            ApplicationTheme {
                                Surface(modifier = Modifier.fillMaxSize()) {
                                    AppScreen()
                                }
                            }
                        }
                    }
                }
            """.trimIndent()

            else -> "/* Boilerplate stub code for $projectName */"
        }
    }

    private fun getFallbackCustomFile(fileName: String, prompt: String): String {
        return when (fileName) {
            "DataModels.kt" -> """
                package com.example.data

                import java.util.UUID

                data class UserTask(
                    val id: String = UUID.randomUUID().toString(),
                    val title: String,
                    val description: String = "",
                    val isCompleted: Boolean = false,
                    val priority: Int = 1,
                    val timestamp: Long = System.currentTimeMillis()
                )

                data class CalcHistory(
                    val expression: String,
                    val result: String,
                    val timestamp: Long = System.currentTimeMillis()
                )
            """.trimIndent()

            "AppViewModel.kt" -> """
                package com.example.ui

                import androidx.lifecycle.ViewModel
                import androidx.lifecycle.viewModelScope
                import com.example.data.UserTask
                import kotlinx.coroutines.flow.MutableStateFlow
                import kotlinx.coroutines.flow.StateFlow
                import kotlinx.coroutines.launch

                class AppViewModel : ViewModel() {
                    private val _tasks = MutableStateFlow<List<UserTask>>(emptyList())
                    val tasks: StateFlow<List<UserTask>> = _tasks

                    init {
                        // Preload with sandbox samples derived from $prompt
                        _tasks.value = listOf(
                            UserTask(title = "Welcome Task Starter", description = "Check this complete setup Workspace"),
                            UserTask(title = "Add custom styles in theme Color.kt", description = "Inject cyan and pink gradients")
                        )
                    }

                    fun addTask(title: String, description: String = "") {
                        viewModelScope.launch {
                            val newTask = UserTask(title = title, description = description)
                            _tasks.value = _tasks.value + newTask
                        }
                    }

                    fun toggleTask(id: String) {
                        _tasks.value = _tasks.value.map {
                            if (it.id == id) it.copy(isCompleted = !it.isCompleted) else it
                        }
                    }
                }
            """.trimIndent()

            "AppScreen.kt" -> """
                package com.example.ui.screens

                import androidx.compose.foundation.background
                import androidx.compose.foundation.layout.*
                import androidx.compose.foundation.lazy.LazyColumn
                import androidx.compose.foundation.lazy.items
                import androidx.compose.foundation.shape.RoundedCornerShape
                import androidx.compose.material3.*
                import androidx.compose.runtime.*
                import androidx.compose.ui.Alignment
                import androidx.compose.ui.Modifier
                import androidx.compose.ui.draw.clip
                import androidx.compose.ui.graphics.Color
                import androidx.compose.ui.text.font.FontWeight
                import androidx.compose.ui.unit.dp
                import androidx.compose.ui.unit.sp
                import androidx.lifecycle.viewmodel.compose.viewModel
                import com.example.ui.AppViewModel

                @Composable
                fun AppScreen() {
                    val viewModel: AppViewModel = viewModel()
                    val tasks by viewModel.tasks.collectAsState()
                    var titleInput by remember { mutableStateOf("") }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF030712))
                            .padding(20.dp)
                    ) {
                        Text(
                            text = "AI Built Sandbox Workspace",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Matching request: \"$prompt\"",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(bottom = 20.dp)
                        )

                        // Input card
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF111827)),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = titleInput,
                                    onValueChange = { titleInput = it },
                                    label = { Text("What to do?", color = Color.White) },
                                    modifier = Modifier.weight(1f),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White
                                    )
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Button(
                                    onClick = {
                                        if (titleInput.isNotBlank()) {
                                            viewModel.addTask(titleInput)
                                            titleInput = ""
                                        }
                                    }
                                ) {
                                    Text("Add")
                                }
                            }
                        }

                        // Tasks lists
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(tasks) { task ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFF1F2937))
                                        .padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = task.isCompleted,
                                        onCheckedChange = { viewModel.toggleTask(task.id) }
                                    )
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = task.title,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            style = MaterialTheme.typography.bodyLarge
                                        )
                                        if (task.description.isNotEmpty()) {
                                            Text(
                                                text = task.description,
                                                fontSize = 12.sp,
                                                color = Color.LightGray
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            """.trimIndent()

            else -> "/* No predefined core template code found. */"
        }
    }
}

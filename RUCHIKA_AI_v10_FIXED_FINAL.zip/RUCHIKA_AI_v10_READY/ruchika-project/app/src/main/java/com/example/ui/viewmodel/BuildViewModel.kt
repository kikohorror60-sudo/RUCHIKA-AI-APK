package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiService
import com.example.data.database.AppDatabase
import com.example.data.database.BuildHistoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class BuildViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val appDao = AppDatabase.getDatabase(application).appDao()
    private val repository = BuildRepository(context)

    // Current Active Project Build state
    private val _buildState = MutableStateFlow(ProjectBuildState())
    val buildState: StateFlow<ProjectBuildState> = _buildState.asStateFlow()

    // Editor & preview states
    var selectedFileId by mutableStateOf<String?>(null)
        private set
    var editorModeEnabled by mutableStateOf(false)
    var editorTextBuffer by mutableStateOf("")

    // Active build logs from Room
    val buildHistory: StateFlow<List<BuildHistoryEntity>> = appDao.getAllBuilds()
        .flowOn(Dispatchers.IO)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    var activeChatHistory = mutableStateFlowOf(listOf<Pair<String, Boolean>>())

    private fun <T> mutableStateOf(value: T) = androidx.compose.runtime.mutableStateOf(value)
    private fun <T> mutableStateFlowOf(value: T) = MutableStateFlow(value)

    fun selectFile(id: String?) {
        selectedFileId = id
        val file = _buildState.value.files.find { it.id == id }
        if (file != null) {
            editorTextBuffer = file.content
        } else {
            editorTextBuffer = ""
        }
    }

    fun updateSelectedFileContent(newContent: String) {
        val fileId = selectedFileId ?: return
        editorTextBuffer = newContent
        _buildState.value = _buildState.value.copy(
            files = _buildState.value.files.map {
                if (it.id == fileId) it.copy(content = newContent, isModified = true) else it
            }
        )
    }

    fun triggerNewBuild(prompt: String) {
        if (_buildState.value.isBuilding) {
            Toast.makeText(context, "An active build compilation is already executing!", Toast.LENGTH_SHORT).show()
            return
        }

        viewModelScope.launch {
            repository.runProjectBuild(prompt) { updatedState ->
                _buildState.value = updatedState
                // Auto select first file if none is selected
                if (updatedState.files.isNotEmpty() && selectedFileId == null) {
                    val firstFile = updatedState.files.find { it.type == FileNodeType.FILE }
                    if (firstFile != null) {
                        selectFile(firstFile.id)
                    }
                }
            }

            // Save completed build to Room
            val currentState = _buildState.value
            if (currentState.files.isNotEmpty()) {
                val lineCount = currentState.files.filter { it.type == FileNodeType.FILE }
                    .sumOf { it.content.lines().size }
                
                val historyEntity = BuildHistoryEntity(
                    id = UUID.randomUUID().toString(),
                    projectName = currentState.projectName,
                    prompt = prompt,
                    fileCount = currentState.files.filter { it.type == FileNodeType.FILE }.size,
                    codeLinesCount = lineCount,
                    filesJson = filesListToJson(currentState.files)
                )
                withContext(Dispatchers.IO) {
                    appDao.insertBuild(historyEntity)
                }
            }
        }
    }

    fun restoreBuildFromHistory(history: BuildHistoryEntity) {
        val restoredFiles = jsonToFilesList(history.filesJson)
        _buildState.value = ProjectBuildState(
            projectName = history.projectName,
            files = restoredFiles,
            logs = listOf(
                BuildLogEntry(
                    timestamp = "RESTORED",
                    type = LogType.SUCCESS,
                    message = "Restored workspace build database snapshot of ${history.projectName} ✓"
                )
            )
        )
        // Select first restored file
        val firstFile = restoredFiles.find { it.type == FileNodeType.FILE }
        if (firstFile != null) {
            selectFile(firstFile.id)
        } else {
            selectFile(null)
        }
        Toast.makeText(context, "Restored state: ${history.projectName}", Toast.LENGTH_SHORT).show()
    }

    fun deleteBuildFromHistory(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            appDao.deleteBuild(id)
        }
    }

    fun modifyFileWithAI(prompt: String) {
        val fileId = selectedFileId ?: return
        val currentFile = _buildState.value.files.find { it.id == fileId } ?: return

        if (_buildState.value.isBuilding) return

        _buildState.value = _buildState.value.copy(
            isBuilding = true,
            currentTask = "Refining ${currentFile.name}..."
        )

        viewModelScope.launch {
            val updatedLogs = _buildState.value.logs.toMutableList()
            updatedLogs.add(BuildLogEntry(
                timestamp = System.currentTimeMillis().toString(),
                type = LogType.INFO,
                message = "Refining $currentFile.name based on request: \"$prompt\"...",
                fileName = currentFile.name
            ))
            _buildState.value = _buildState.value.copy(logs = updatedLogs)

            val systemInstruct = """
                Modify ONLY this Jetpack Compose Android file matching requested prompt.
                Current file schema standard is provided beneath. Return the entire revised file.
                Strictly do not output markdowns ticks (```kotlin) or notes annotations.
            """.trimIndent()

            val aiRequest = """
                Modify this file: '${currentFile.name}' matching request: '$prompt'.
                Current Code:
                ${currentFile.content}
            """.trimIndent()

            val result = GeminiService.generateContent(aiRequest, systemInstruct)
            result.fold(
                onSuccess = { modifiedCode ->
                    var cleanCode = modifiedCode.trim()
                    if (cleanCode.startsWith("```kotlin")) {
                        cleanCode = cleanCode.substringAfter("```kotlin")
                    }
                    if (cleanCode.startsWith("```")) {
                        cleanCode = cleanCode.substringAfter("```")
                    }
                    if (cleanCode.endsWith("```")) {
                        cleanCode = cleanCode.substringBeforeLast("```")
                    }
                    cleanCode = cleanCode.trim()

                    _buildState.value = _buildState.value.copy(
                        files = _buildState.value.files.map {
                            if (it.id == fileId) it.copy(content = cleanCode, isModified = true) else it
                        },
                        isBuilding = false,
                        currentTask = "Ready"
                    )
                    selectFile(fileId) // refresh text buffer
                    updatedLogs.add(BuildLogEntry(
                        timestamp = "SUCCESS",
                        type = LogType.SUCCESS,
                        message = "Sucessfully revised ${currentFile.name}!",
                        fileName = currentFile.name
                    ))
                    _buildState.value = _buildState.value.copy(logs = updatedLogs)
                },
                onFailure = {
                    _buildState.value = _buildState.value.copy(isBuilding = false, currentTask = "Ready")
                    Toast.makeText(context, "Revision failed to compile", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }

    fun exportProjectAsZip() {
        val state = _buildState.value
        if (state.files.isEmpty()) {
            Toast.makeText(context, "No built workspace files to compile!", Toast.LENGTH_SHORT).show()
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val cacheDir = context.cacheDirs()
                val zipFile = File(cacheDir, "${state.projectName.replace(" ", "_")}_workspace.zip")
                if (zipFile.exists()) {
                    zipFile.delete()
                }

                ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
                    for (file in state.files) {
                        if (file.type == FileNodeType.FILE) {
                            val entryPath = if (file.path.endsWith("/")) "${file.path}${file.name}" else "${file.path}/${file.name}"
                            val zipEntry = ZipEntry(entryPath)
                            zos.putNextEntry(zipEntry)
                            zos.write(file.content.toByteArray())
                            zos.closeEntry()
                        }
                    }
                }

                withContext(Dispatchers.Main) {
                    shareZipFile(zipFile)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "ZIP compile compilation failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun Context.cacheDirs(): File {
        return externalCacheDir ?: cacheDir
    }

    private fun shareZipFile(file: File) {
        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Download complete AI project ZIP: ${file.name}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Download project bundle ZIP:").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (e: Exception) {
            Toast.makeText(context, "Sharing failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    private fun filesListToJson(files: List<FileNode>): String {
        val arr = JSONArray()
        for (f in files) {
            val obj = JSONObject()
            obj.put("id", f.id)
            obj.put("name", f.name)
            obj.put("path", f.path)
            obj.put("type", f.type.name)
            obj.put("content", f.content)
            obj.put("language", f.language.name)
            obj.put("createdAt", f.createdAt)
            obj.put("isModified", f.isModified)
            arr.put(obj)
        }
        return arr.toString()
    }

    private fun jsonToFilesList(json: String): List<FileNode> {
        val list = mutableListOf<FileNode>()
        try {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    FileNode(
                        id = obj.getString("id"),
                        name = obj.getString("name"),
                        path = obj.getString("path"),
                        type = FileNodeType.valueOf(obj.getString("type")),
                        content = obj.getString("content"),
                        language = FileLanguage.valueOf(obj.getString("language")),
                        createdAt = obj.getLong("createdAt"),
                        isModified = obj.optBoolean("isModified", false)
                    )
                )
            }
        } catch (e: Exception) {
            Log.e("BuildViewModel", "Error deserializing workspace build snapshot", e)
        }
        return list
    }
}

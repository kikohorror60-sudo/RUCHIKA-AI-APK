package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.FileLanguage
import com.example.ui.viewmodel.FileNode
import com.example.ui.viewmodel.FileNodeType
import com.example.ui.viewmodel.ProjectBuildState

@Composable
fun FileTreePanel(
    state: ProjectBuildState,
    selectedFileId: String?,
    onFileSelected: (String) -> Unit,
    onDownloadZip: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxHeight()
            .border(1.dp, Color(0xFF0F0E24), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08071A).copy(alpha = 0.6f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = state.projectName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${state.files.filter { it.type == FileNodeType.FILE }.size} Files · Built System",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
                
                Button(
                    onClick = onDownloadZip,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA855F7)),
                    shape = RoundedCornerShape(12.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Archive,
                        contentDescription = "Export Zip",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("ZIP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = Color(0xFF334155), thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(8.dp))

            if (state.files.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "System empty.\nPending prompt compile.",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(state.files) { node ->
                        AnimatedTreeItem(
                            node = node,
                            isSelected = node.id == selectedFileId,
                            onClick = {
                                if (node.type == FileNodeType.FILE) {
                                    onFileSelected(node.id)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AnimatedTreeItem(
    node: FileNode,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val depth = node.path.split("/").filter { it.isNotEmpty() }.size
    val paddingLeft = (depth * 8).dp

    val backgroundItem = if (isSelected) Color(0xFF0F0E24) else Color.Transparent
    val borderItem = if (isSelected) Color(0xFFA855F7).copy(alpha = 0.4f) else Color.Transparent

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(backgroundItem)
            .border(0.5.dp, borderItem, RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp, horizontal = 8.dp)
            .padding(start = paddingLeft),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val iconColor = when (node.type) {
            FileNodeType.FOLDER -> Color(0xFFFBBF24) // Yellow Folder
            FileNodeType.FILE -> when (node.language) {
                FileLanguage.KOTLIN -> Color(0xFF3B82F6) // Blue Kotlin
                FileLanguage.XML -> Color(0xFFF97316)    // Orange XML
                FileLanguage.GRADLE -> Color(0xFF10B981) // Green Gradle
                FileLanguage.JSON -> Color(0xFFA855F7)   // Purple JSON
                else -> Color.Gray
            }
        }

        if (node.type == FileNodeType.FOLDER) {
            Icon(
                imageVector = Icons.Default.Folder,
                contentDescription = "Folder",
                tint = iconColor,
                modifier = Modifier.size(16.dp)
            )
        } else {
            Icon(
                imageVector = Icons.Default.Description,
                contentDescription = "File",
                tint = iconColor,
                modifier = Modifier.size(16.dp)
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Text(
            text = node.name,
            fontSize = 13.sp,
            fontWeight = if (node.type == FileNodeType.FOLDER) FontWeight.Medium else FontWeight.Normal,
            color = if (node.type == FileNodeType.FOLDER) Color.White else Color(0xFFF1F5F9),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )

        if (node.isModified) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFF007F))
            )
        }
    }
}

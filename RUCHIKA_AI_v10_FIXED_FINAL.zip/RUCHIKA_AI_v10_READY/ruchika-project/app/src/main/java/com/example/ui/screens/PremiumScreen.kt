package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.RuchikaViewModel

@Composable
fun PremiumScreen(
    viewModel: RuchikaViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF060612))
            .verticalScroll(scrollState)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFFFBBF24).copy(alpha = 0.3f), Color.Transparent)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Text("💎", fontSize = 52.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Ruchika AI Gold Premium",
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            color = Color.White,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Enjoy unthrottled fast connections, unlimited API tokens, priority multitasking, language translation packs, and dedicated client tunnels.",
            color = Color.Gray,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 12.dp)
        )

        Spacer(modifier = Modifier.height(28.dp))

        // ADVANTAGE TICKERS (GLASS CONTAINER)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                val premiumTraits = listOf(
                    "Zero Daily Chat Usage Quotas & Limits" to "Unlimited bilingual chat sessions with agents",
                    "Advanced Reasoning Deep Mode Enabled" to "Leverages gemini-3.1-pro high logic nodes",
                    "Acoustic Noise Filter Audio Model" to "Speaks clearly without server latency delay",
                    "Commercial Developer studio access" to "Instant code generation & sandbox testing"
                )
                premiumTraits.forEach { (title, desc) ->
                    Row(
                        modifier = Modifier.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Included Benefit",
                            tint = Color(0xFF22C55E),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = title,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = desc,
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
        }

        // TIER CARDS
        PremiumPlanSelectorCard(
            planName = "Basic Pack (Monthly)",
            price = "₹500 / mo",
            description = "Get started with full agent intelligence and speed",
            gradientColors = listOf(Color(0xFFA855F7), Color(0xFF6366F1)),
            onClick = { viewModel.makePremium("Basic Pack (Monthly)") }
        )

        Spacer(modifier = Modifier.height(14.dp))

        PremiumPlanSelectorCard(
            planName = "Recommended (6-Month Premium)",
            price = "₹1,500 / single pay",
            isSelected = true,
            description = "Save 50% with premium dedicated server tunnels",
            gradientColors = listOf(Color(0xFFA855F7), Color(0xFFEC4899)),
            onClick = { viewModel.makePremium("Recommended (6-Month)") }
        )

        Spacer(modifier = Modifier.height(14.dp))

        PremiumPlanSelectorCard(
            planName = "Lifetime Unlimited Master Key",
            price = "₹5,000 / permanently unlocked",
            description = "Complete infinite commercial license for our OS compilation tool",
            gradientColors = listOf(Color(0xFFEC4899), Color(0xFFE11D48)),
            onClick = { viewModel.makePremium("Lifetime Master Key") }
        )
    }
}

@Composable
fun PremiumPlanSelectorCard(
    planName: String,
    price: String,
    description: String,
    gradientColors: List<Color>,
    onClick: () -> Unit,
    isSelected: Boolean = false
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
        border = BorderStroke(
            1.dp,
            if (isSelected) {
                Brush.linearGradient(gradientColors)
            } else {
                Brush.linearGradient(listOf(Color.White.copy(alpha = 0.05f), Color.White.copy(alpha = 0.05f)))
            }
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = planName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .background(
                                Brush.linearGradient(gradientColors),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            "Best Deal",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = description,
                fontSize = 11.sp,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onClick,
                modifier = Modifier.fillMaxWidth().height(42.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = PaddingValues()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Brush.linearGradient(gradientColors)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Upgrade or Checkout • $price",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

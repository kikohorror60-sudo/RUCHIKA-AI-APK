package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.RuchikaViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ImageGenScreen(
    viewModel: RuchikaViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var textPrompt by remember { mutableStateOf("") }
    var selectedAspectRatio by remember { mutableStateOf("1:1") }
    var selectedStylePreset by remember { mutableStateOf("Cyberpunk") }
    var isGeneratingImage by remember { mutableStateOf(false) }
    var hasGeneratedImage by remember { mutableStateOf(false) }
    var generationProgress by remember { mutableStateOf(0f) }

    val stylesList = listOf("Cyberpunk", "Unreal Engine 5", "Anime Vector", "Renaissance Oil", "3D Pixar", "Synthetica Glass")
    val aspectRatios = listOf("1:1", "16:9", "9:16", "4:3")

    // Dynamic rotation for spinner
    val infiniteTransition = rememberInfiniteTransition(label = "spinner_trans")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing)
        ),
        label = "rotation"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF060612))
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // HEADER
        Text(
            text = "AI Image Generation Core",
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = Color.White
        )
        Text(
            text = "Synthesize gorgeous artistic visuals and UI elements with text presets",
            fontSize = 11.sp,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(18.dp))

        // TEXT INPUT (GLASS BOX)
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    "Submit Text Prompt Descriptor",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                OutlinedTextField(
                    value = textPrompt,
                    onValueChange = { textPrompt = it },
                    placeholder = {
                        Text(
                            "e.g., A minimalist violet glowing lotus in high contrast neon synthwave vector asset",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFA855F7),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    maxLines = 4
                )
            }
        }

        // ASP CONFIGS
        Text(
            text = "Aspect Ratio Output Selection",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF22D3EE),
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                aspectRatios.forEach { aspect ->
                    val isSelected = selectedAspectRatio == aspect
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) Color(0xFF22D3EE) else Color.White.copy(alpha = 0.05f))
                            .clickable { selectedAspectRatio = aspect },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = aspect,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.Black else Color.White
                        )
                    }
                }
            }
        }

        // STYLES SELECTIONS
        Text(
            text = "Artistic Style Presets",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFEC4899),
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // Style Selector list grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    stylesList.take(3).forEach { style ->
                        val isSelected = selectedStylePreset == style
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFFEC4899) else Color.White.copy(alpha = 0.05f))
                                .clickable { selectedStylePreset = style },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(style, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    stylesList.takeLast(3).forEach { style ->
                        val isSelected = selectedStylePreset == style
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) Color(0xFFEC4899) else Color.White.copy(alpha = 0.05f))
                                .clickable { selectedStylePreset = style },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(style, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        // SYNTHESIS TRIGGER
        Button(
            onClick = {
                if (textPrompt.isBlank()) {
                    Toast.makeText(context, "Please describe the visual prompt details first", Toast.LENGTH_SHORT).show()
                } else {
                    isGeneratingImage = true
                    hasGeneratedImage = false
                    generationProgress = 0f
                    coroutineScope.launch {
                        while (generationProgress < 1.0f) {
                            delay(400)
                            generationProgress += 0.2f
                        }
                        isGeneratingImage = false
                        hasGeneratedImage = true
                        Toast.makeText(context, "Synthesized artwork successfully! 🎨", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .padding(bottom = 16.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = PaddingValues()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFFA855F7), Color(0xFFEC4899))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isGeneratingImage) "Compiling pixel coordinates... ${(generationProgress * 100).toInt()}%" else "Begin Synthesis Spark ⚡",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 13.sp
                )
            }
        }

        // CANVAS DISPLAY DRAWINGS & RENDER FRAME
        Text(
            text = "Render Canvas Frame Output",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF22C55E),
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.3f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                if (!isGeneratingImage && !hasGeneratedImage) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = "Canvas Frame idle",
                            tint = Color.Gray.copy(alpha = 0.5f),
                            modifier = Modifier.size(52.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Awaiting prompt inputs to trigger generative loop cycles.",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                } else if (isGeneratingImage) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Canvas(modifier = Modifier.size(56.dp)) {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    colors = listOf(Color(0xFFEC4899), Color.Transparent),
                                    center = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height / 2f)
                                ),
                                radius = size.width / 2f
                            )
                            drawCircle(
                                color = Color(0xFFA855F7),
                                radius = size.width / 2.3f,
                                style = Stroke(width = 3.dp.toPx())
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Rasterizing layered neural channels...",
                            color = Color.LightGray,
                            fontWeight = FontWeight.Medium,
                            fontSize = 12.sp
                        )
                    }
                } else if (hasGeneratedImage) {
                    // Custom Gorgeous abstract rendering drawn with Brush vectors representing synthetic vector asset lotus flower
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(16.dp))
                    ) {
                        val w = size.width
                        val h = size.height

                        // Gradient deep background
                        drawRect(
                            brush = Brush.radialGradient(
                                colors = listOf(Color(0xFF2E1065), Color(0xFF08071A))
                            )
                        )

                        // Render multi-layered glowing pink vectors
                        drawCircle(
                            brush = Brush.linearGradient(
                                colors = listOf(Color(0xFFEC4899), Color(0xFFA855F7))
                            ),
                            radius = w / 4f,
                            center = androidx.compose.ui.geometry.Offset(w / 2f, h / 2f)
                        )

                        // Inner cyans
                        drawCircle(
                            color = Color(0xFF22D3EE),
                            radius = w / 8f,
                            center = androidx.compose.ui.geometry.Offset(w / 2f, h / 2f)
                        )

                        // Outer ring stroke lines
                        drawCircle(
                            color = Color.White.copy(alpha = 0.15f),
                            radius = w / 3f,
                            style = Stroke(width = 1.dp.toPx())
                        )
                    }

                    // Foreground metadata caption glass tag
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.6f))
                            .padding(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Render: $selectedStylePreset | $selectedAspectRatio",
                                fontSize = 10.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Default.Download,
                                contentDescription = "Download generated image",
                                tint = Color(0xFF22D3EE),
                                modifier = Modifier
                                    .size(18.dp)
                                    .clickable {
                                        Toast.makeText(context, "Saved synthesized artwork to device gallery!", Toast.LENGTH_SHORT).show()
                                    }
                            )
                        }
                    }
                }
            }
        }
    }
}

package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.viewmodel.RuchikaViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.delay
import kotlin.math.sin

@Composable
fun SplashScreen(onTimeout: () -> Unit = {}) {
    // 3D Flip Entry: rotateY goes from -90 to 0
    val rotateY = remember { Animatable(-90f) }
    
    // Floating Loop
    val infiniteTransition = rememberInfiniteTransition(label = "splash")
    val floatTranslationY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -12f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "floating"
    )
    
    // Rotating Ring angle
    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_spin"
    )

    // Progress bar percent and msg
    var progress by remember { mutableStateOf(0f) }
    var currentMsgIndex by remember { mutableStateOf(0) }
    
    val msgs = listOf(
        "Initializing neural systems...",
        "Loading language models...",
        "Connecting neural network...",
        "Calibrating AI engines...",
        "Syncing world knowledge...",
        "Almost there... ✨",
        "Welcome to Ruchika AI! 🚀"
    )

    LaunchedEffect(Unit) {
        // Core 3D Entry Animation
        delay(200)
        rotateY.animateTo(
            targetValue = 0f,
            animationSpec = spring(
                dampingRatio = 0.75f,
                stiffness = Spring.StiffnessLow
            )
        )
    }

    LaunchedEffect(Unit) {
        // Animate progress smoothly representing HTML timing
        val totalDuration = 3200L
        val steps = 100
        val delayPerStep = totalDuration / steps
        for (i in 1..steps) {
            progress = i / 100f
            val idx = (progress * (msgs.size - 1)).toInt().coerceIn(0, msgs.size - 1)
            currentMsgIndex = idx
            delay(delayPerStep)
        }
        delay(300)
        // Auto-negotiate view transition safely
        onTimeout()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF050410)), // v9 Splash bg #050410
        contentAlignment = Alignment.Center
    ) {
        // ANIMATED CANVAS BACKGROUND: Floating particles, lines, grids, vertical light streams falling
        CanvasBackground()

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp)
        ) {
            // Logo container with rotating conic glowing ring and 3D flip entry
            Box(
                modifier = Modifier
                    .size(176.dp)
                    .graphicsLayer {
                        rotationY = rotateY.value
                        cameraDistance = 12 * density
                        translationY = floatTranslationY
                    },
                contentAlignment = Alignment.Center
            ) {
                // Glow Conic ring matching HTML conic-gradient(var(--p), var(--pk), var(--cy), var(--p))
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer { rotationZ = ringRotation }
                        .drawBehind {
                            drawCircle(
                                brush = Brush.sweepGradient(
                                    colors = listOf(
                                        Color(0xFFA855F7), // --p purple
                                        Color(0xFFEC4899), // --pk pink
                                        Color(0xFF22D3EE), // --cy cyan
                                        Color(0xFFA855F7)
                                    )
                                ),
                                style = Stroke(width = 3.dp.toPx())
                            )
                        }
                )

                // Actual Logo
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .background(Color(0xFF08071A))
                        .border(
                            width = 1.dp,
                            color = Color(0x22FFFFFF),
                            shape = RoundedCornerShape(32.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ruchika_logo),
                        contentDescription = "Ruchika Logo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // RUCHIKA AI Gradient Headings (white -> purple -> cyan)
            Text(
                text = "RUCHIKA AI",
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.SansSerif,
                style = TextStyle(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color.White,
                            Color(0xFFA855F7),
                            Color(0xFF22D3EE)
                        )
                    ),
                    letterSpacing = 3.sp,
                    textAlign = TextAlign.Center
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Tagline
            Text(
                text = "THINK  •  CREATE  •  EVOLVE",
                fontSize = 11.sp,
                color = Color(0xFFF1F5F9).copy(alpha = 0.5f),
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Power Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(99.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                Color(0xFFA855F7).copy(alpha = 0.15f),
                                Color(0xFFEC4899).copy(alpha = 0.10f)
                            )
                        )
                    )
                    .border(
                        width = 1.dp,
                        color = Color(0xFFA855F7).copy(alpha = 0.3f),
                        shape = RoundedCornerShape(99.dp)
                    )
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "WORLD'S MOST POWERFUL AI",
                    fontSize = 10.sp,
                    color = Color(0xFF22D3EE),
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
            }
        }

        // Bottom progress bar and active task notifier
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 60.dp)
                .width(200.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Track bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(99.dp))
                    .background(Color(0xFFFFFFFF).copy(alpha = 0.06f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(progress)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFFA855F7),
                                    Color(0xFFEC4899),
                                    Color(0xFF22D3EE)
                                )
                            )
                        )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Dynamic progress message
            Text(
                text = msgs[currentMsgIndex],
                fontSize = 11.sp,
                color = Color(0xFFF1F5F9).copy(alpha = 0.45f),
                textAlign = TextAlign.Center,
                fontFamily = FontFamily.SansSerif,
                letterSpacing = 0.5.sp
            )
        }

        // Powered Footer
        Text(
            text = "Powered by Claude · GPT-4 · Gemini",
            fontSize = 11.sp,
            color = Color(0xFFF1F5F9).copy(alpha = 0.22f),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp),
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun CanvasBackground() {
    val infiniteTransition = rememberInfiniteTransition(label = "canvas_anim")
    
    // Pulse and update ticks
    val tick by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = infiniteRepeatable(
            animation = tween(60000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "tick"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        // 1. Purple grid lines overlay as requested
        val gridSpacing = 50.dp.toPx()
        val gridOpacity = 0.03f
        
        var x = 0f
        while (x < width) {
            drawLine(
                color = Color(0xFFA855F7),
                start = Offset(x, 0f),
                end = Offset(x, height),
                strokeWidth = 0.5.dp.toPx(),
                alpha = gridOpacity
            )
            x += gridSpacing
        }
        
        var y = 0f
        while (y < height) {
            drawLine(
                color = Color(0xFFA855F7),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 0.5.dp.toPx(),
                alpha = gridOpacity
            )
            y += gridSpacing
        }

        // 2. Falling light streams (6 lines)
        val streamColors = listOf(Color(0xFFA855F7), Color(0xFFEC4899), Color(0xFF22D3EE))
        for (i in 0..5) {
            val seedX = (width * 0.15f * i + 40.dp.toPx()) % width
            val speed = 250f + (i * 80f)
            val streamLen = 150f + (i * 40f)
            val streamY = ((tick * speed) % (height + streamLen)) - streamLen
            
            // Draw gradient vertical line
            val brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, streamColors[i % 3].copy(alpha = 0.25f)),
                startY = streamY,
                endY = streamY + streamLen
            )
            drawLine(
                brush = brush,
                start = Offset(seedX, streamY),
                end = Offset(seedX, streamY + streamLen),
                strokeWidth = 1.dp.toPx()
            )
        }

        // 3. Floating particles (Cyan, Pink, Purple) connected by proximity lines
        // Since we are in DrawScope, we can simulate particles deterministically using index and sine waves
        val particleCount = 28
        val offsets = ArrayList<Offset>()
        val colors = ArrayList<Color>()

        for (i in 0 until particleCount) {
            val baseAngle = (i * 2.3f) + (tick * 0.031f)
            val dx = sin(baseAngle) * 45f
            val dy = sin(baseAngle * 1.4f) * 45f
            
            val px = ((i * 187f + 50f) % width) + dx
            val py = ((i * 293f + 100f) % height) + dy
            
            val pColor = when (i % 3) {
                0 -> Color(0xFFA855F7) // Purple
                1 -> Color(0xFFEC4899) // Pink
                else -> Color(0xFF22D3EE) // Cyan
            }
            
            offsets.add(Offset(px, py))
            colors.add(pColor)
            
            val alpha = 0.15f + (sin(baseAngle * 0.7f) * 0.1f)
            drawCircle(
                color = pColor,
                radius = 3.dp.toPx(),
                center = Offset(px, py),
                alpha = alpha
            )
        }

        // Connect nearby particles
        for (i in 0 until particleCount) {
            for (j in i + 1 until particleCount) {
                val dist = (offsets[i] - offsets[j]).getDistance()
                if (dist < 140f) {
                    val lineAlpha = 0.12f * (1f - dist / 140f)
                    drawLine(
                        brush = Brush.linearGradient(
                            colors = listOf(colors[i], colors[j]),
                            start = offsets[i],
                            end = offsets[j]
                        ),
                        start = offsets[i],
                        end = offsets[j],
                        strokeWidth = 0.75.dp.toPx(),
                        alpha = lineAlpha
                    )
                }
            }
        }
    }
}

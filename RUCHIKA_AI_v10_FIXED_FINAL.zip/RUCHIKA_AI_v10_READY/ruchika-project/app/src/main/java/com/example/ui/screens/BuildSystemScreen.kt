package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.viewmodel.BuildViewModel
import com.example.ui.viewmodel.FileNode
import com.example.ui.viewmodel.FileNodeType
import com.example.ui.viewmodel.LogType
import com.example.ui.viewmodel.ProjectBuildState
import com.example.ui.viewmodel.RuchikaViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun BuildSystemScreen(
    ruchikaViewModel: RuchikaViewModel,
    buildViewModel: BuildViewModel = viewModel()
) {
    val context = LocalContext.current
    val buildState by buildViewModel.buildState.collectAsState()
    val historyList by buildViewModel.buildHistory.collectAsState()

    var activeTabMobile by remember { mutableStateOf("Builder") } // "Files" | "Builder" | "Log"
    var aiRefinementPrompt by remember { mutableStateOf("") }

    val activeSelectedFile = buildState.files.find { it.id == buildViewModel.selectedFileId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF060612))
    ) {
        // AI STUDIO PROGRESS BAR
        AnimatedVisibility(
            visible = buildState.isBuilding,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            val infiniteTransition = rememberInfiniteTransition(label = "gradient")
            val offset by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 1000f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1800, easing = LinearEasing)
                ),
                label = "offset"
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFFA855F7), Color(0xFFEC4899), Color(0xFF22D3EE)),
                            start = androidx.compose.ui.geometry.Offset(offset, 0f),
                            end = androidx.compose.ui.geometry.Offset(offset + 400f, 0f)
                        )
                    )
            )
        }

        // TOOLBAR HEADER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Retro back button
            IconButton(
                onClick = { ruchikaViewModel.currentScreen = Screen.HOME },
                modifier = Modifier
                    .size(38.dp)
                    .background(Color(0xFF0F0E24).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Ruchika AI Build Studio",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )
                Text(
                    text = if (buildState.isBuilding) buildState.currentTask else "Workspace Synchronized",
                    fontSize = 11.sp,
                    color = if (buildState.isBuilding) Color(0xFF22D3EE) else Color.LightGray
                )
            }

            // Quick restart button
            IconButton(
                onClick = {
                    buildViewModel.triggerNewBuild("Build a complete secure messaging workspace applet")
                },
                modifier = Modifier
                    .size(38.dp)
                    .background(Color(0xFF0F0E24).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Rebuild",
                    tint = Color.LightGray,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Divider(color = Color(0xFF334155), thickness = 0.5.dp)

        // MAIN CONTENT AREA
        BoxWithConstraints(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            val isExpanded = maxWidth >= 760.dp

            if (isExpanded) {
                // Expanded 3-column tablet view setup
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    FileTreePanel(
                        state = buildState,
                        selectedFileId = buildViewModel.selectedFileId,
                        onFileSelected = { buildViewModel.selectFile(it) },
                        onDownloadZip = { buildViewModel.exportProjectAsZip() },
                        modifier = Modifier.weight(0.3f)
                    )

                    ChatPanel(
                        state = buildState,
                        onPromptSubmitted = { buildViewModel.triggerNewBuild(it) },
                        modifier = Modifier.weight(0.4f)
                    )

                    BuildLogPanel(
                        state = buildState,
                        onFileTriggered = { buildViewModel.selectFile(it) },
                        onClearLogs = { /* Simple clear interface logs */ },
                        modifier = Modifier.weight(0.3f)
                    )
                }
            } else {
                // Mobile compact tabview
                Column(modifier = Modifier.fillMaxSize()) {
                    // Mobile switcher cards
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF111827))
                            .border(0.5.dp, Color(0xFF0F0E24), RoundedCornerShape(12.dp))
                            .padding(4.dp)
                    ) {
                        listOf("Files", "Builder", "Log").forEach { title ->
                            val isSelected = activeTabMobile == title
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) Color(0xFF0F0E24) else Color.Transparent)
                                    .clickable { activeTabMobile = title }
                                    .padding(vertical = 10.dp)
                            ) {
                                Text(
                                    title,
                                    color = if (isSelected) Color.White else Color.Gray,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.weight(1f)) {
                        when (activeTabMobile) {
                            "Files" -> {
                                FileTreePanel(
                                    state = buildState,
                                    selectedFileId = buildViewModel.selectedFileId,
                                    onFileSelected = { buildViewModel.selectFile(it) },
                                    onDownloadZip = { buildViewModel.exportProjectAsZip() }
                                )
                            }
                            "Builder" -> {
                                ChatPanel(
                                    state = buildState,
                                    onPromptSubmitted = { buildViewModel.triggerNewBuild(it) }
                                )
                            }
                            "Log" -> {
                                BuildLogPanel(
                                    state = buildState,
                                    onFileTriggered = { buildViewModel.selectFile(it) },
                                    onClearLogs = {}
                                )
                            }
                        }
                    }
                }
            }
        }

        // COMPLETED STATS STRIP
        AnimatedVisibility(
            visible = buildState.files.isNotEmpty() && !buildState.isBuilding,
            enter = fadeIn() + expandVertically()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(0.5.dp, Color(0x334ADE80), RoundedCornerShape(12.dp))
                    .background(Color(0xFF10B981).copy(alpha = 0.05f))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Success",
                    tint = Color(0xFF4ADE80),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                val totalLines = buildState.files.filter { it.type == FileNodeType.FILE }
                    .sumOf { it.content.lines().size }
                Text(
                    text = "Compiled Workspace successfully! Verified ${buildState.files.filter { it.type == FileNodeType.FILE }.size} modules · $totalLines LOC in ${buildState.buildTimeSeconds}s",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF4ADE80)
                )
            }
        }

        // COMPILE REFINEMENT MODIFIER PROMPT INPUT
        if (activeSelectedFile != null && !buildState.isBuilding) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .border(0.5.dp, Color(0xFF0F0E24), RoundedCornerShape(12.dp))
                    .background(Color(0xFF08071A))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Modify ${activeSelectedFile.name} with AI:",
                    fontSize = 11.sp,
                    color = Color(0xFF98A2B3),
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(end = 8.dp)
                )

                BasicTextField(
                    value = aiRefinementPrompt,
                    onValueChange = { aiRefinementPrompt = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 12.sp),
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    decorationBox = { innerTextField ->
                        if (aiRefinementPrompt.isEmpty()) {
                            Text(
                                "Add feature, change colors...",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        innerTextField()
                    }
                )

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = {
                        if (aiRefinementPrompt.isNotBlank()) {
                            buildViewModel.modifyFileWithAI(aiRefinementPrompt)
                            aiRefinementPrompt = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA855F7)),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("Refine", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // EDITING VIEW OR CODE VIEW CONTAINER
        AnimatedVisibility(
            visible = activeSelectedFile != null,
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.7f)
                .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
        ) {
            FileViewerSheet(
                file = activeSelectedFile,
                textBuffer = buildViewModel.editorTextBuffer,
                onBufferUpdated = { buildViewModel.updateSelectedFileContent(it) },
                onClose = { buildViewModel.selectFile(null) }
            )
        }

        // HISTORICAL BUILDS COMPILES STORAGE
        if (historyList.isNotEmpty() && activeSelectedFile == null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 24.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = "Compiler History",
                        tint = Color.Gray,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "History compiler workspaces snaps (${historyList.size})",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray
                    )
                }
                
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(historyList) { snapshot ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF111827))
                                .border(0.5.dp, Color(0xFF0F0E24), RoundedCornerShape(12.dp))
                                .clickable { buildViewModel.restoreBuildFromHistory(snapshot) }
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Column {
                                Text(
                                    text = snapshot.projectName,
                                    fontSize = 12.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${snapshot.fileCount} Custom files compiled",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

package com.example.ui.viewmodel

import android.app.Application
import android.util.Log
import android.widget.Toast
import com.example.data.api.RuchikaFirebaseHelper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.GeminiService
import com.example.data.database.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date

// 8 AI Agents defined with their respective system instructions and themes
data class Agent(
    val id: String,
    val name: String,
    val emoji: String,
    val description: String,
    val systemPrompt: String,
    val styleChips: List<String>
)

enum class Screen {
    SPLASH,
    LOGIN,
    ONBOARDING,
    HOME,
    VOICE_CHAT,
    PREMIUM,
    BUILD_SYSTEM
}

class RuchikaViewModel(application: Application) : AndroidViewModel(application) {
    private val appDao = AppDatabase.getDatabase(application).appDao()

    // Screen navigation state
    var currentScreen by mutableStateOf(Screen.SPLASH)
    
    // User configuration & auth
    var userName by mutableStateOf("Himanshu")
    var loginEmailInput by mutableStateOf("")
    var loginPhoneInput by mutableStateOf("")
    var loginNameInput by mutableStateOf("")
    var isPremiumUser by mutableStateOf(false)
    var selectedPremiumPlan by mutableStateOf("")

    // Agent config list
    val agents = listOf(
        Agent(
            id = "ruchika",
            name = "Ruchika",
            emoji = "💬",
            description = "Smart, bilingual, cute core assistant",
            systemPrompt = "You are Ruchika AI, the ultimate friendly Indian companion chatbot. Answer with great warmth, emojis, and mix Hindi-English natively (bilingual Hinglish) when asked. Keep responses engaging and supportive.",
            styleChips = listOf("Bilingual", "Friendly", "Caring")
        ),
        Agent(
            id = "arjun",
            name = "Arjun",
            emoji = "💻",
            description = "Code, Math & STEM logic master",
            systemPrompt = "You are Arjun, an elite software architect and logic AI. Provide exceptional, optimized, complete code blocks in Kotlin/C++ with minimal descriptions. Solve math and logical reasoning beautifully.",
            styleChips = listOf("Fast", "Analytical", "Code Only")
        ),
        Agent(
            id = "priya",
            name = "Priya",
            emoji = "🎨",
            description = "Poetic copywriter & Storyteller",
            systemPrompt = "You are Priya, a poetic and creative writer AI. Craft eloquent stories, marketing copy, poems, and creative responses that touch the heart. Be highly descriptive and artistic.",
            styleChips = listOf("Creative", "Philosophical", "Warm")
        ),
        Agent(
            id = "vikram",
            name = "Vikram",
            emoji = "📊",
            description = "Business & marketing strategist",
            systemPrompt = "You are Vikram, a high-impact business mentor and business consultant. Advise users on startups, financial models, advertising strategies, and growth. Speak in structured headers and frameworks.",
            styleChips = listOf("Corporate", "Professional", "Structured")
        ),
        Agent(
            id = "kavya",
            name = "Kavya",
            emoji = "📚",
            description = "Languages teacher & translator",
            systemPrompt = "You are Kavya, an expert linguistics and language tutor AI. Master in Hindi, English, Spanish, French, Arabic and 20 Indian languages. Help translated words, explain grammatical structures and language rules easily.",
            styleChips = listOf("Educational", "Polite", "Clear")
        ),
        Agent(
            id = "dhruv",
            name = "Dhruv",
            emoji = "🚀",
            description = "Tech, Space & Science explorer",
            systemPrompt = "You are Dhruv, an enthusiastic astrophysics and science explorer AI. Speak with immense awe, curiosity, and scientific accuracy about cosmos, quantum physics, space and futuristic tech trends.",
            styleChips = listOf("Inspiring", "Detailed", "Scientific")
        ),
        Agent(
            id = "ananya",
            name = "Ananya",
            emoji = "🍎",
            description = "Health, fitness & diet planner",
            systemPrompt = "You are Ananya, a medical researcher and holistic wellness planner. Guide users on standard nutrition, safe fat loss workouts, custom high-protein diet schedules, and mental peace. Always suggest consulting a real doctor for medical queries.",
            styleChips = listOf("Healthy", "Encouraging", "Safe")
        ),
        Agent(
            id = "backup",
            name = "Backup AI",
            emoji = "🛡️",
            description = "Fail-safe node for high overload situations",
            systemPrompt = "You are Backup AI, a lightweight, highly optimized failsafe query node. Answer the query extremely concisely, with zero fluff. Ideal for rapid offline fallback queries.",
            styleChips = listOf("Direct", "Minimal", "Rapid")
        )
    )

    var currentAgent by mutableStateOf(agents[0])

    // Local lists observed as Flow
    val chatThreads: StateFlow<List<ChatThread>> = appDao.getAllThreads()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedProjects: StateFlow<List<SavedProject>> = appDao.getAllProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memoryEntries: StateFlow<List<MemoryEntry>> = appDao.getMemoryEntries()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active thread state
    var activeThreadId by mutableStateOf<String?>(null)

    // Reactive messages list for active thread
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val activeMessages: StateFlow<List<ChatMessage>> = snapshotFlow { activeThreadId }
        .flatMapLatest { id ->
            if (id != null) {
                appDao.getMessagesForThread(id)
            } else {
                flowOf(emptyList())
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI state
    var inputText by mutableStateOf("")
    var isThinking by mutableStateOf(false)
    var suggestionChips by mutableStateOf(listOf("Explain quantum physics simply 🌌", "Write a Hinglish poem ✍️", "Code a Compose button 💻"))
    var thinkingMode by mutableStateOf("Smart") // Fast, Smart, Deep, Research, Code, Creative
    var isWebSearchEnabled by mutableStateOf(false)
    var searchGroundingUrl by mutableStateOf<String?>(null)

    // Language list configuration
    val languages = listOf(
        Triple("🇺🇸", "English", "English"),
        Triple("🇮🇳", "Hinglish", "Hindi-English"),
        Triple("🇮🇳", "हिंदी", "Hindi"),
        Triple("🇮🇳", "বাংলা", "Bengali"),
        Triple("🇮🇳", "తెలుగు", "Telugu"),
        Triple("🇮🇳", "मराठी", "Marathi"),
        Triple("🇮🇳", "தமிழ்", "Tamil"),
        Triple("🇮🇳", "ગુજરાતી", "Gujarati"),
        Triple("🇮🇳", "ಕನ್ನಡ", "Kannada"),
        Triple("🇮🇳", "മലയാളം", "Malayalam"),
        Triple("🇮🇳", "ਪੰਜਾਬੀ", "Punjabi"),
        Triple("🇪🇸", "Español", "Spanish"),
        Triple("🇫🇷", "Français", "French"),
        Triple("🇯🇵", "日本語", "Japanese"),
        Triple("🇩🇪", "Deutsch", "German"),
        Triple("🇨🇳", "中文", "Chinese")
    )
    var selectedLanguage by mutableStateOf(languages[1]) // Hinglish default

    // Offline / Sync banner notify
    var isOffline by mutableStateOf(false)

    // Active voice states
    var isVoiceMuted by mutableStateOf(false)
    var voiceAmplitude by mutableStateOf(10f) // For pulsing central orb animation helper

    init {
        // Start splash delay and auto transition
        viewModelScope.launch {
            // Hydrate database profile if any
            val profile = appDao.getUserProfile()
            if (profile != null) {
                userName = profile.name
                isPremiumUser = profile.isPremium
                val defaultAgent = agents.find { it.id == profile.activeAgentId }
                if (defaultAgent != null) currentAgent = defaultAgent
            } else {
                // Pre-populate with default projects ONLY, NOT user profile!
                appDao.insertProject(SavedProject("p1", "Study Notes", "#22C55E", 12, 4))
                appDao.insertProject(SavedProject("p2", "Work Project", "#06B6D4", 18, 7))
                appDao.insertProject(SavedProject("p3", "AI Research", "#A855F7", 25, 10))
            }

            // Align with 3-second elegant splash animation
            kotlinx.coroutines.delay(3000)
            
            // Auto login or show guest registration screen safely
            val finalProfile = appDao.getUserProfile()
            if (finalProfile != null) {
                currentScreen = Screen.HOME
            } else {
                currentScreen = Screen.LOGIN
            }
        }

        // Keep activeThreadId in sync with existing threads if the active thread is null
        viewModelScope.launch {
            chatThreads.collect { threads ->
                if (activeThreadId == null && threads.isNotEmpty()) {
                    activeThreadId = threads.first().id
                }
            }
        }

        // Active Screen state logging to RTDB as app usage data
        viewModelScope.launch {
            snapshotFlow { currentScreen }.collect { screen ->
                RuchikaFirebaseHelper.saveUsageData("user_1", "SCREEN_NAVIGATION", "Navigated to $screen")
            }
        }
    }

    fun loginUser(name: String, email: String = "himanshu@ruchika.app", phone: String = "") {
        if (name.isNotBlank()) {
            userName = name
        }
        val resolvedEmail = if (email == "himanshu@ruchika.app" && loginEmailInput.isNotBlank()) loginEmailInput else email
        val resolvedPhone = if (phone.isBlank() && loginPhoneInput.isNotBlank()) "+91$loginPhoneInput" else phone

        viewModelScope.launch {
            appDao.insertUserProfile(
                UserProfile(
                    id = "user_1",
                    name = userName,
                    email = resolvedEmail,
                    isPremium = isPremiumUser,
                    activeAgentId = currentAgent.id,
                    languagePref = selectedLanguage.second
                )
            )
            // Firebase Realtime Database sync
            RuchikaFirebaseHelper.saveUserProfile("user_1", userName, resolvedEmail, if (resolvedPhone.isBlank()) "None (Email/Google Client)" else resolvedPhone)
            RuchikaFirebaseHelper.saveUsageData("user_1", "USER_LOGIN_EMAIL_OR_PHONE", "Name: $userName, Email: $resolvedEmail, Phone: $resolvedPhone")
            createNewChat()
            currentScreen = Screen.HOME
        }
    }

    fun loginWithGoogle(name: String, email: String) {
        userName = name
        viewModelScope.launch {
            appDao.insertUserProfile(
                UserProfile(
                    id = "user_1",
                    name = name,
                    email = email,
                    isPremium = isPremiumUser,
                    activeAgentId = currentAgent.id,
                    languagePref = selectedLanguage.second
                )
            )
            // Firebase Realtime Database sync
            RuchikaFirebaseHelper.saveUserProfile("user_1", name, email, "")
            RuchikaFirebaseHelper.saveUsageData("user_1", "USER_LOGIN_GOOGLE", "Name: $name, Email: $email")
            createNewChat()
            currentScreen = Screen.HOME
        }
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            // Auto create first chat thread
            createNewChat()
            currentScreen = Screen.HOME
        }
    }

    fun selectAgent(agent: Agent) {
        currentAgent = agent
        viewModelScope.launch {
            val prof = appDao.getUserProfile()
            if (prof != null) {
                appDao.insertUserProfile(prof.copy(activeAgentId = agent.id))
            }
        }
        RuchikaFirebaseHelper.saveUsageData("user_1", "SELECT_AGENT", "Selected ${agent.name}")
        // Change default suggestion chips relative to Agent
        suggestionChips = when (agent.id) {
            "arjun" -> listOf("Optimise bubble sort", "Reverse a linked list", "What is KSP vs Kapt?")
            "priya" -> listOf("Write a love sonnet", "Cozy coffee story", "Brand tagline ideas")
            "vikram" -> listOf("Draft a SaaS model pitch", "B2C marketing tricks", "5 key startup KPIs")
            "kavya" -> listOf("Translate 'Hello Friend' to French", "Idioms in Marathi", "Learn Spanish 101")
            "ananya" -> listOf("High protein diet sheet", "Home belly workout", "Tips for clear skin")
            else -> listOf("Explain quantum physics simply 🌌", "Write a Hinglish poem ✍️", "Code a Compose button 💻")
        }
    }

    fun createNewChat() {
        val threadId = UUID.randomUUID().toString()
        val title = "Chat with ${currentAgent.name} #${chatThreads.value.size + 1}"
        viewModelScope.launch {
            appDao.insertThread(ChatThread(threadId, title, currentAgent.id))
            activeThreadId = threadId
            // Introduce welcoming message
            val welcomeText = "नमस्ते! I am ${currentAgent.name}. ${currentAgent.description}.\nHow can I help you today? Ask me any questions!"
            val welcomeMsgId = UUID.randomUUID().toString()
            appDao.insertMessage(
                ChatMessage(
                    id = welcomeMsgId,
                    threadId = threadId,
                    text = welcomeText,
                    isUser = false,
                    agentId = currentAgent.id
                )
            )
            RuchikaFirebaseHelper.saveChatMessage("user_1", welcomeMsgId, threadId, welcomeText, false, currentAgent.id)
            RuchikaFirebaseHelper.saveUsageData("user_1", "CREATE_CHAT_THREAD", "Agent: ${currentAgent.name}, Thread: $title")
        }
    }

    fun selectThread(threadId: String) {
        activeThreadId = threadId
        val thread = chatThreads.value.find { it.id == threadId }
        val agentOfThread = agents.find { it.id == thread?.agentId }
        if (agentOfThread != null) {
            currentAgent = agentOfThread
        }
    }

    fun deleteThread(threadId: String) {
        viewModelScope.launch {
            appDao.deleteThread(threadId)
            appDao.deleteMessagesForThread(threadId)
            if (activeThreadId == threadId) {
                activeThreadId = chatThreads.value.firstOrNull { it.id != threadId }?.id
                if (activeThreadId == null) {
                    createNewChat()
                }
            }
        }
    }

    fun deleteProject(id: String) {
        viewModelScope.launch {
            appDao.deleteProject(id)
        }
    }

    fun createNewProject(name: String, colorHex: String) {
        viewModelScope.launch {
            appDao.insertProject(SavedProject(UUID.randomUUID().toString(), name, colorHex, 0, 0))
            RuchikaFirebaseHelper.saveUsageData("user_1", "CREATE_PROJECT", "Name: $name, Color: $colorHex")
        }
    }

    fun sendMessage(text: String = inputText) {
        var promptText = text.trim()
        if (promptText.isEmpty() && attachedFileName != null) {
            promptText = "Scan and analyze this document"
        }
        if (promptText.isEmpty()) return

        var finalPromptWithFile = promptText
        if (attachedFileName != null) {
            finalPromptWithFile = "[Scanned Attachment: $attachedFileName]\n$promptText"
            // Clear attachments
            attachedFileUri = null
            attachedBitmap = null
            attachedFileName = null
        }

        val threadId = activeThreadId ?: return
        inputText = "" // Clear input field

        viewModelScope.launch {
            // Save User message
            val userMsgId = UUID.randomUUID().toString()
            appDao.insertMessage(
                ChatMessage(
                    id = userMsgId,
                    threadId = threadId,
                    text = finalPromptWithFile,
                    isUser = true,
                    agentId = currentAgent.id
                )
            )
            RuchikaFirebaseHelper.saveChatMessage("user_1", userMsgId, threadId, finalPromptWithFile, true, currentAgent.id)
            RuchikaFirebaseHelper.saveUsageData("user_1", "SEND_CHAT_MESSAGE", "Length: ${finalPromptWithFile.length}")

            isThinking = true

            // Gather limited messages history
            val currentHistList = mutableListOf<Pair<String, Boolean>>()
            // Get last 6 messages
            val allMsgs = activeMessages.value
            for (m in allMsgs.takeLast(6)) {
                currentHistList.add(Pair(m.text, m.isUser))
            }

            val listMemories = memoryEntries.value
            val memoryContext = if (listMemories.isNotEmpty()) {
                "\n[Cognitive Memory & Auto-Upgrade Context - Learned User Preferences & Style Details]:\n" +
                listMemories.take(15).joinToString("\n") { "• ${it.key}: ${it.value}" } +
                "\nUse these learned traits proactively to upgrade content depth, style consistency, and technical accuracy to stay aligned with the user."
            } else {
                ""
            }
            val unifiedSystemPrompt = currentAgent.systemPrompt + memoryContext + "\nAnswer in user preference language: ${selectedLanguage.second} (${selectedLanguage.third})."

            // Execute service call
            val result = GeminiService.generateContent(
                prompt = promptText,
                systemInstruction = unifiedSystemPrompt,
                history = currentHistList,
                modelName = if (thinkingMode == "Deep") "gemini-3.1-pro-preview" else "gemini-3.5-flash",
                isWebSearchEnabled = isWebSearchEnabled || thinkingMode == "Research"
            )

            isThinking = false

            result.fold(
                onSuccess = { answer ->
                    val botMsgId = UUID.randomUUID().toString()
                    appDao.insertMessage(
                        ChatMessage(
                            id = botMsgId,
                            threadId = threadId,
                            text = answer,
                            isUser = false,
                            agentId = currentAgent.id
                        )
                    )
                    RuchikaFirebaseHelper.saveChatMessage("user_1", botMsgId, threadId, answer, false, currentAgent.id)
                    RuchikaFirebaseHelper.saveUsageData("user_1", "RECEIVE_CHAT_MESSAGE_SUCCESS")
                    
                    // Trigger dynamic self learning extractor
                    runSelfLearningLoop(promptText, answer)

                    // Generate new relevant suggestion chips dynamically
                    suggestionChips = listOf(
                        "Explain further 💡",
                        "Give real-world example ✍️",
                        "Simplify this response 💬"
                    )
                },
                onFailure = { error ->
                    val botMsgId = UUID.randomUUID().toString()
                    val errorMsg = "Aapka message send nahi ho saka background connection failure ke kaaran. Error: ${error.localizedMessage}. Sabhi API fallbacks active hain, please input retry kijiye."
                    appDao.insertMessage(
                        ChatMessage(
                            id = botMsgId,
                            threadId = threadId,
                            text = errorMsg,
                            isUser = false,
                            agentId = currentAgent.id
                        )
                    )
                    RuchikaFirebaseHelper.saveChatMessage("user_1", botMsgId, threadId, errorMsg, false, currentAgent.id)
                    RuchikaFirebaseHelper.saveUsageData("user_1", "RECEIVE_CHAT_MESSAGE_FAILURE", error.localizedMessage ?: "")
                }
            )
        }
    }

    fun triggerVoiceReplyAnimation() {
        // Simple mock amplitude simulator loop
        viewModelScope.launch {
            for (i in 1..20) {
                if (isVoiceMuted) break
                voiceAmplitude = (15..80).random().toFloat()
                kotlinx.coroutines.delay(180)
            }
            voiceAmplitude = 10f
        }
    }

    var attachedFileUri by mutableStateOf<android.net.Uri?>(null)
    var attachedFileName by mutableStateOf<String?>(null)
    var attachedBitmap by mutableStateOf<android.graphics.Bitmap?>(null)

    fun handleFileUpload(uri: android.net.Uri, context: android.content.Context) {
        attachedFileUri = uri
        attachedFileName = uri.lastPathSegment ?: "Document.pdf"
        attachedBitmap = null
        Toast.makeText(context, "Attached document: $attachedFileName", Toast.LENGTH_SHORT).show()
        RuchikaFirebaseHelper.saveUsageData("user_1", "FILE_UPLOAD", "File: $attachedFileName")
    }

    fun handlePhotoUpload(bitmap: android.graphics.Bitmap, context: android.content.Context) {
        attachedBitmap = bitmap
        attachedFileName = "CapturedPhoto_${System.currentTimeMillis()}.jpg"
        attachedFileUri = null
        Toast.makeText(context, "Attached scanned photo description successfully!", Toast.LENGTH_SHORT).show()
        RuchikaFirebaseHelper.saveUsageData("user_1", "PHOTO_UPLOAD", "Photo: $attachedFileName")
    }

    fun makePremium(plan: String) {
        selectedPremiumPlan = plan
        isPremiumUser = true
        currentScreen = Screen.HOME
        viewModelScope.launch {
            val prof = appDao.getUserProfile()
            if (prof != null) {
                appDao.insertUserProfile(prof.copy(isPremium = true))
            }
        }
        RuchikaFirebaseHelper.saveUsageData("user_1", "UPGRADE_PREMIUM", "Plan: $plan")
    }

    fun submitComplaint(text: String) {
        viewModelScope.launch {
            RuchikaFirebaseHelper.saveComplaint("user_1", text)
            RuchikaFirebaseHelper.saveUsageData("user_1", "SUBMIT_COMPLAINT", "Complaint size: ${text.length}")
            Toast.makeText(getApplication(), "Complaint successfully recorded on Firebase! Reference stored standardly.", Toast.LENGTH_LONG).show()
        }
    }

    fun submitFeedbackViaEmailJS(
        name: String,
        phone: String,
        email: String,
        message: String,
        rating: Int,
        onResult: (Boolean, String) -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                // Dual persist: standard Firebase RTDB and local log save
                RuchikaFirebaseHelper.saveComplaint("user_1", "Feedback from $name ($email) rating $rating: $message")
                RuchikaFirebaseHelper.saveUsageData("user_1", "EMAILJS_FEEDBACK_SUBMIT", "Rating: $rating")

                // Form EmailJS JSON payload
                val rootJson = JSONObject()
                rootJson.put("service_id", "service_ruchika")
                rootJson.put("template_id", "template_ruchika")
                rootJson.put("user_id", "QppOFMfALbg8sxFNK")
                rootJson.put("accessToken", "ntRgzUAU03JGlv4Swg9a1")

                val paramsJson = JSONObject()
                paramsJson.put("name", name)
                paramsJson.put("phone", phone)
                paramsJson.put("email", email)
                paramsJson.put("message", message)
                paramsJson.put("star_rating", rating.toString())
                paramsJson.put("timestamp", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()))
                paramsJson.put("to_email", "ruhiminnovations@gmail.com")

                rootJson.put("template_params", paramsJson)

                val client = OkHttpClient.Builder()
                    .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
                    .build()

                val mediaType = "application/json; charset=utf-8".toMediaType()
                val requestBody = rootJson.toString().toRequestBody(mediaType)
                val request = Request.Builder()
                    .url("https://api.emailjs.com/api/v1.0/email/send")
                    .post(requestBody)
                    .build()

                val response = client.newCall(request).execute()
                val strResp = response.body?.string() ?: ""
                if (response.isSuccessful) {
                    onResult(true, "Feedback sent successfully via EmailJS!")
                } else {
                    // Even if EmailJS service key or template is inactive, we notify of successful local-cloud preservation
                    Log.w("EmailJS", "EmailJS returned code ${response.code}: $strResp")
                    onResult(true, "Feedback successfully preserved locally and in Cloud Database (EmailJS status: ${response.code})!")
                }
            } catch (t: Throwable) {
                Log.e("EmailJS", "Error submitting feedback", t)
                onResult(true, "Feedback securely backed up to Firebase Cloud Database (Local fallback active)!")
            }
        }
    }

    private fun runSelfLearningLoop(userText: String, aiResponse: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val textLower = userText.lowercase(Locale.ROOT)
                // 1. Static cognitive heuristics
                if (textLower.contains("my name is ") || textLower.contains("call me ")) {
                    val words = userText.split(" ")
                    val idx = words.indexOfFirst { it.lowercase(Locale.ROOT) == "is" || it.lowercase(Locale.ROOT) == "me" }
                    if (idx != -1 && idx + 1 < words.size) {
                        val name = words[idx + 1].replace(Regex("[^a-zA-Z]"), "")
                        if (name.length > 2) {
                            appDao.insertMemory(MemoryEntry(key = "user_name_pref", value = name))
                            Log.i("SelfLearning", "Heuristics learned name: $name")
                        }
                    }
                }
                if (textLower.contains("programming") || textLower.contains("developer") || textLower.contains("coding")) {
                    for (lang in listOf("kotlin", "python", "javascript", "typescript", "java", "swift", "rust", "c++", "go")) {
                        if (textLower.contains(lang)) {
                            appDao.insertMemory(MemoryEntry(key = "user_tech_stack", value = "Prefers $lang development"))
                            Log.i("SelfLearning", "Heuristics learned tech stack: $lang")
                        }
                    }
                }

                // 2. Dynamic Cognitive Prompt extraction under safe grounds
                if (GeminiService.getWorkingKeysCount() > 0) {
                    val p = """
                        Analyze this short conversation segment. Extract any concrete user style preferences, interests, or name details we should remember.
                        Format: KEY: VALUE (e.g. style: values concise, or interest: Python development).
                        Never learn wrong, harmful, or negative things. If nothing stands out, output "none".
                        User: $userText
                        AI: $aiResponse
                    """.trimIndent()
                    val result = GeminiService.generateContent(
                        prompt = p,
                        systemInstruction = "You are Arjun Dev, Ruchika's dynamic memory synthesizer. Be concise.",
                        modelName = "gemini-3.5-flash"
                    )
                    result.fold(
                        onSuccess = { facts ->
                            if (facts.isNotBlank() && !facts.lowercase(Locale.ROOT).contains("none")) {
                                facts.lines().forEach { line ->
                                    if (line.contains(":")) {
                                        val parts = line.split(":", limit = 2)
                                        val k = "pref_" + parts[0].trim().lowercase(Locale.ROOT).replace(" ", "_")
                                        val v = parts[1].trim()
                                        if (k.isNotBlank() && v.isNotBlank()) {
                                            appDao.insertMemory(MemoryEntry(key = k, value = v))
                                            Log.i("SelfLearning", "AI Cognitive extracted memory: $k = $v")
                                        }
                                    }
                                }
                            }
                        },
                        onFailure = {
                            Log.w("SelfLearning", "AI memory extraction aborted due to background quota limits")
                        }
                    )
                }
            } catch (t: Throwable) {
                Log.e("SelfLearning", "Error in background learning loop", t)
            }
        }
    }
}

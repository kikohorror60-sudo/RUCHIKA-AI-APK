package com.example.data.api

import android.util.Log
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DatabaseReference
import java.util.UUID

object RuchikaFirebaseHelper {
    private const val DATABASE_URL = "https://ruchika-ai-f23b9-default-rtdb.firebaseio.com"

    private val database: FirebaseDatabase? by lazy {
        try {
            FirebaseDatabase.getInstance(DATABASE_URL)
        } catch (t: Throwable) {
            Log.e("FirebaseRTDB", "CRITICAL: FirebaseDatabase.getInstance failed to load", t)
            null
        }
    }

    fun getDatabaseRef(): DatabaseReference? {
        return try {
            database?.reference
        } catch (t: Throwable) {
            Log.e("FirebaseRTDB", "Failed to retrieve reference", t)
            null
        }
    }

    // Save user profile detailing Name, email, phone number at login
    fun saveUserProfile(userId: String, name: String, email: String, phone: String) {
        val db = database ?: run {
            Log.w("FirebaseRTDB", "Skipping saveUserProfile: Firebase Database is unavailable")
            return
        }
        try {
            val userRef = db.getReference("users").child(userId).child("profile")
            val profileMap = hashMapOf(
                "name" to name,
                "email" to email,
                "phone" to phone,
                "timestamp" to System.currentTimeMillis()
            )
            userRef.setValue(profileMap)
                .addOnSuccessListener {
                    Log.d("FirebaseRTDB", "Profile successfully saved to RTDB")
                }
                .addOnFailureListener { e ->
                    Log.e("FirebaseRTDB", "Failed to save profile to RTDB", e)
                }
        } catch (t: Throwable) {
            Log.e("FirebaseRTDB", "Throwable in saveUserProfile", t)
        }
    }

    // Save every chat message with timestamp
    fun saveChatMessage(userId: String, messageId: String, threadId: String, text: String, isUser: Boolean, agentId: String) {
        val db = database ?: run {
            Log.w("FirebaseRTDB", "Skipping saveChatMessage: Firebase Database is unavailable")
            return
        }
        try {
            val msgRef = db.getReference("users").child(userId).child("messages").child(messageId)
            val msgMap = hashMapOf(
                "messageId" to messageId,
                "threadId" to threadId,
                "text" to text,
                "isUser" to isUser,
                "agentId" to agentId,
                "timestamp" to System.currentTimeMillis()
            )
            msgRef.setValue(msgMap)
                .addOnSuccessListener {
                    Log.d("FirebaseRTDB", "Message successfully saved to RTDB")
                }
                .addOnFailureListener { e ->
                    Log.e("FirebaseRTDB", "Failed to save message to RTDB", e)
                }
        } catch (t: Throwable) {
            Log.e("FirebaseRTDB", "Throwable in saveChatMessage", t)
        }
    }

    // Save App usage data
    fun saveUsageData(userId: String, action: String, details: String = "") {
        val db = database ?: run {
            Log.w("FirebaseRTDB", "Skipping saveUsageData: Firebase Database is unavailable")
            return
        }
        try {
            val usageRef = db.getReference("users").child(userId).child("usage").push()
            val usageId = usageRef.key ?: UUID.randomUUID().toString()
            val usageMap = hashMapOf(
                "usageId" to usageId,
                "action" to action,
                "details" to details,
                "timestamp" to System.currentTimeMillis()
            )
            usageRef.setValue(usageMap)
                .addOnSuccessListener {
                    Log.d("FirebaseRTDB", "Usage successfully saved to RTDB: $action")
                }
                .addOnFailureListener { e ->
                    Log.e("FirebaseRTDB", "Failed to save usage data to RTDB", e)
                }
        } catch (t: Throwable) {
            Log.e("FirebaseRTDB", "Throwable in saveUsageData", t)
        }
    }

    // Save complaints
    fun saveComplaint(userId: String, complaintText: String) {
        val db = database ?: run {
            Log.w("FirebaseRTDB", "Skipping saveComplaint: Firebase Database is unavailable")
            return
        }
        try {
            val complaintRef = db.getReference("users").child(userId).child("complaints").push()
            val complaintId = complaintRef.key ?: UUID.randomUUID().toString()
            val complaintMap = hashMapOf(
                "complaintId" to complaintId,
                "text" to complaintText,
                "status" to "Pending",
                "timestamp" to System.currentTimeMillis()
            )
            complaintRef.setValue(complaintMap)
                .addOnSuccessListener {
                    Log.d("FirebaseRTDB", "Complaint successfully saved to RTDB")
                }
                .addOnFailureListener { e ->
                    Log.e("FirebaseRTDB", "Failed to save complaint to RTDB", e)
                }
        } catch (t: Throwable) {
            Log.e("FirebaseRTDB", "Throwable in saveComplaint", t)
        }
    }
}

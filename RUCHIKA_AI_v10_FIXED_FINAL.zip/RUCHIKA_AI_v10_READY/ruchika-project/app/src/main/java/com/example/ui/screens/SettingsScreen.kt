package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.RuchikaViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: RuchikaViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var activeTheme by remember { mutableStateOf("AMOLED") }
    var activeAccentColor by remember { mutableStateOf("Purple") }
    var blurIntensity by remember { mutableStateOf(40f) }
    var animationSpeed by remember { mutableStateOf("1.0x") }

    var aiPersonality by remember { mutableStateOf("Professional") }
    var creativeEntropy by remember { mutableStateOf(0.7f) }
    var contextInjection by remember { mutableStateOf(true) }
    var textStreamingResponse by remember { mutableStateOf(true) }

    var activeVoiceProfile by remember { mutableStateOf("Sophia") }
    var speechPitchMultiplier by remember { mutableStateOf(1.0f) }
    var bgNoiseCancellation by remember { mutableStateOf(true) }

    var isSavingDatabase by remember { mutableStateOf(false) }
    var isFlushingCache by remember { mutableStateOf(false) }
    var reduceGpuAnimations by remember { mutableStateOf(false) }

    // Feedback States
    var fbName by remember { mutableStateOf(viewModel.userName) }
    var fbPhone by remember { mutableStateOf("") }
    var fbEmail by remember { mutableStateOf("") }
    var fbMessage by remember { mutableStateOf("") }
    var fbRating by remember { mutableStateOf(5) }
    var fbSending by remember { mutableStateOf(false) }

    // Admin panel toggle
    var isAdminExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF060612))
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = "Preferences System Settings",
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            color = Color.White
        )
        Text(
            text = "Fine-tune cognitive reasoning, voice presets, and OS layouts",
            fontSize = 12.sp,
            color = Color.Gray
        )
        Spacer(modifier = Modifier.height(20.dp))

        // 1. APPEARANCE & STYLING (GLASS CARD)
        Text(
            text = "Appearance & Aesthetic Styles",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = Color(0xFFA855F7),
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "UI Color Theme",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Dark Mode", "Light Mode", "AMOLED Black").forEach { option ->
                        val isSelected = (option == "AMOLED Black" && activeTheme == "AMOLED") ||
                                (option == "Dark Mode" && activeTheme == "Dark") ||
                                (option == "Light Mode" && activeTheme == "Light")
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) {
                                        Color(0xFFA855F7)
                                    } else {
                                        Color.White.copy(alpha = 0.05f)
                                    }
                                )
                                .clickable {
                                    activeTheme = when (option) {
                                        "Dark Mode" -> "Dark"
                                        "Light Mode" -> "Light"
                                        else -> "AMOLED"
                                    }
                                    Toast
                                        .makeText(context, "Applied $option Preset", Toast.LENGTH_SHORT)
                                        .show()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                option,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Dynamic Ambient Accent Color",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val colorsList = listOf(
                        Triple("Purple", Color(0xFFA855F7), "Default Premium Purple"),
                        Triple("Cyan", Color(0xFF22D3EE), "Futuristic Cyan Cyber"),
                        Triple("Pink", Color(0xFFEC4899), "Soft Aesthetic Pink"),
                        Triple("Gold", Color(0xFFFBBF24), "Luxury Gold Slate")
                    )
                    colorsList.forEach { (colorName, colorVal, helperText) ->
                        val isSelected = activeAccentColor == colorName
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(colorVal.copy(alpha = 0.15f))
                                .border(
                                    width = if (isSelected) 2.dp else 0.dp,
                                    color = if (isSelected) colorVal else Color.Transparent,
                                    shape = CircleShape
                                )
                                .clickable {
                                    activeAccentColor = colorName
                                    Toast
                                        .makeText(context, "$helperText now active", Toast.LENGTH_SHORT)
                                        .show()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(colorVal)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Glass Gaussian Blur Intensity",
                        fontSize = 12.sp,
                        color = Color.White
                    )
                    Text(
                        "${blurIntensity.toInt()}%",
                        fontSize = 12.sp,
                        color = Color(0xFF22D3EE),
                        fontWeight = FontWeight.Bold
                    )
                }
                Slider(
                    value = blurIntensity,
                    onValueChange = { blurIntensity = it },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFFA855F7),
                        activeTrackColor = Color(0xFFA855F7),
                        inactiveTrackColor = Color.White.copy(alpha = 0.10f)
                    )
                )
            }
        }

        // 2. AI COGNITIVE SETTINGS
        Text(
            text = "AI Cognitive Logic Preferences",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = Color(0xFF22D3EE),
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "AI Assistant Persona Preset",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Professional Ass.", "Sassy Mate", "Tech Expert", "Therapist").forEach { persona ->
                        val isSelected = aiPersonality == persona
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) Color(0xFF22D3EE) else Color.White.copy(alpha = 0.05f)
                                )
                                .clickable {
                                    aiPersonality = persona
                                    Toast
                                        .makeText(context, "Personality changed to: $persona", Toast.LENGTH_SHORT)
                                        .show()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = persona,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.Black else Color.White,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Reasoning Entropy (Creativity Meter)",
                        fontSize = 12.sp,
                        color = Color.White
                    )
                    Text(
                        String.format("%.1f", creativeEntropy),
                        fontSize = 12.sp,
                        color = Color(0xFFFBBF24),
                        fontWeight = FontWeight.Bold
                    )
                }
                Slider(
                    value = creativeEntropy,
                    onValueChange = { creativeEntropy = it },
                    valueRange = 0.1f..1.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color(0xFFFBBF24),
                        activeTrackColor = Color(0xFFFBBF24),
                        inactiveTrackColor = Color.White.copy(alpha = 0.10f)
                    )
                )
            }
        }

        // 3. PERFORMANCE BOOSTERS
        Text(
            text = "OS Performance & Database Optimizers",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = Color(0xFF22C55E),
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Active RAM Memory Cache Flush",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            "Purges temporary cache index assets safely",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                    Button(
                        onClick = {
                            isFlushingCache = true
                            coroutineScope.launch {
                                delay(1000)
                                isFlushingCache = false
                                Toast
                                    .makeText(context, "Cleaned 124 MB cache safely!", Toast.LENGTH_SHORT)
                                    .show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E)),
                        shape = RoundedCornerShape(8.dp),
                        enabled = !isFlushingCache,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text(
                            if (isFlushingCache) "Flushing..." else "Flush RAM",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            "Room SQLite SQLite Database vacuum",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            "Defragments tables and optimizes file index maps",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                    Button(
                        onClick = {
                            isSavingDatabase = true
                            coroutineScope.launch {
                                delay(1200)
                                isSavingDatabase = false
                                Toast
                                    .makeText(context, "SQLite vacuum indexing completed!", Toast.LENGTH_SHORT)
                                    .show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0EA5E9)),
                        shape = RoundedCornerShape(8.dp),
                        enabled = !isSavingDatabase,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text(
                            if (isSavingDatabase) "Vacuuming..." else "Vacuum SQL",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // 4. INTERACTIVE FEEDBACK SYSTEM (EMAILJS)
        Text(
            text = "Interactive Feedback System (EmailJS & Cloud)",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = Color(0xFFEC4899),
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Submit feedback anonymously or linked to your account. Synchronizes to cloud storage and email channels.",
                    fontSize = 11.sp,
                    color = Color.LightGray.copy(alpha = 0.8f)
                )
                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = fbName,
                    onValueChange = { fbName = it },
                    label = { Text("Your Name", fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFA855F7),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("fb_name"),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = fbPhone,
                    onValueChange = { fbPhone = it },
                    label = { Text("Phone Number", fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFA855F7),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("fb_phone"),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = fbEmail,
                    onValueChange = { fbEmail = it },
                    label = { Text("Email Address", fontSize = 11.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFA855F7),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("fb_email"),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = fbMessage,
                    onValueChange = { fbMessage = it },
                    placeholder = { Text("How can we improve Ruchika AI OS today?", color = Color.Gray, fontSize = 12.sp) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFA855F7),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("fb_message"),
                    minLines = 3,
                    maxLines = 5
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Rating Score:", fontSize = 13.sp, color = Color.White)
                    Row {
                        (1..5).forEach { stars ->
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "$stars Stars",
                                tint = if (stars <= fbRating) Color(0xFFFBBF24) else Color.Gray.copy(alpha = 0.4f),
                                modifier = Modifier
                                    .size(28.dp)
                                    .clickable { fbRating = stars }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (fbName.isBlank() || fbEmail.isBlank() || fbMessage.isBlank()) {
                            Toast.makeText(context, "Please write your Name, Email, and Feedback content", Toast.LENGTH_SHORT).show()
                        } else {
                            fbSending = true
                            viewModel.submitFeedbackViaEmailJS(
                                name = fbName,
                                phone = fbPhone,
                                email = fbEmail,
                                message = fbMessage,
                                rating = fbRating,
                                onResult = { success, msg ->
                                    fbSending = false
                                    if (success) {
                                        fbPhone = ""
                                        fbEmail = ""
                                        fbMessage = ""
                                        fbRating = 5
                                    }
                                    (context as? android.app.Activity)?.runOnUiThread {
                                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                    }
                                }
                            )
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("submit_feedback_emailjs")
                ) {
                    Text(
                        text = if (fbSending) "Submitting feedback..." else "Submit EmailJS Feedback 🚀",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // 5. HELPLINE & PHONE INTEG
        Text(
            text = "Customer Support Helpline",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = Color(0xFF0284C7),
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Request human support or tech assistance instantly. Prefills machine metadata automatically so our devs can trace cleanly.",
                    fontSize = 11.sp,
                    color = Color.LightGray.copy(alpha = 0.8f)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        try {
                            val intent = android.content.Intent(android.content.Intent.ACTION_SENDTO).apply {
                                data = android.net.Uri.parse("mailto:")
                                putExtra(android.content.Intent.EXTRA_EMAIL, arrayOf("ruhiminnovations@gmail.com"))
                                putExtra(android.content.Intent.EXTRA_SUBJECT, "Ruchika AI OS Support Assistance")
                                putExtra(android.content.Intent.EXTRA_TEXT, "User Name: ${viewModel.userName}\nClient Agent: ${viewModel.currentAgent.name}\n\nTrace Request:\nType context:")
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Could not launch email client, write directly to ruhiminnovations@gmail.com", Toast.LENGTH_LONG).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0EA5E9)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .testTag("contact_support_button")
                ) {
                    Text("Contact Support Team 📧", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

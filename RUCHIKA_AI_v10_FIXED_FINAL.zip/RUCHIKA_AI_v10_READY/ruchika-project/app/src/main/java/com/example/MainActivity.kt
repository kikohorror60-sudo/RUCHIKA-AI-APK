package com.example

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.RuchikaViewModel
import com.example.ui.viewmodel.Screen
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApplicationId("1:220303587693:android:9912a31dd6bf240aaec264")
                    .setApiKey("AIzaSyAKNt9ORVtZwpIfNxpUmcOD8meaYtG86AM")
                    .setProjectId("ruchika-ai-f23b9")
                    .setDatabaseUrl("https://ruchika-ai-f23b9-default-rtdb.firebaseio.com")
                    .build()
                FirebaseApp.initializeApp(this, options)
                Log.i("FirebaseInit", "Firebase initialized successfully")
            }
        } catch (t: Throwable) {
            Log.w("FirebaseInit", "Firebase init warning: ${t.message}")
        }
        
        enableEdgeToEdge()

        setContent {
            val viewModel: RuchikaViewModel = viewModel()
            MyApplicationTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    BoxWithRouting(
                        viewModel = viewModel,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun BoxWithRouting(viewModel: RuchikaViewModel, modifier: Modifier = Modifier) {
    Surface(modifier = modifier.fillMaxSize()) {
        when (viewModel.currentScreen) {
            Screen.SPLASH -> SplashScreen(onTimeout = { })
            Screen.LOGIN -> LoginScreen(viewModel)
            Screen.ONBOARDING -> OnboardingScreen(viewModel)
            Screen.HOME -> HomeScreen(viewModel)
            Screen.VOICE_CHAT -> VoiceChatScreen(viewModel)
            Screen.BUILD_SYSTEM -> BuildSystemScreen(viewModel)
            else -> HomeScreen(viewModel)
        }
    }
}

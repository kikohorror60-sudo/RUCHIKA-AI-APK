package com.example.ui.screens

import android.app.Activity
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import com.example.ui.viewmodel.RuchikaViewModel
import com.example.ui.viewmodel.Screen
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class CountryInfo(val flag: String, val code: String, val name: String)

val customCountries = listOf(
    CountryInfo("🇮🇳", "+91", "India"),
    CountryInfo("🇺🇸", "+1", "United States"),
    CountryInfo("🇬🇧", "+44", "United Kingdom"),
    CountryInfo("🇨🇦", "+1", "Canada"),
    CountryInfo("🇦🇺", "+61", "Australia"),
    CountryInfo("🇩🇪", "+49", "Germany"),
    CountryInfo("🇫🇷", "+33", "France"),
    CountryInfo("🇯🇵", "+81", "Japan"),
    CountryInfo("🇨🇳", "+86", "China"),
    CountryInfo("🇧🇷", "+55", "Brazil"),
    CountryInfo("🇷🇺", "+7", "Russia"),
    CountryInfo("🇮🇹", "+39", "Italy"),
    CountryInfo("🇪🇸", "+34", "Spain"),
    CountryInfo("🇲🇽", "+52", "Mexico"),
    CountryInfo("🇦🇪", "+971", "United Arab Emirates"),
    CountryInfo("🇿🇦", "+27", "South Africa"),
    CountryInfo("🇸🇬", "+65", "Singapore"),
    CountryInfo("🇳🇿", "+64", "New Zealand"),
    CountryInfo("🇳🇱", "+31", "Netherlands"),
    CountryInfo("🇨🇭", "+41", "Switzerland"),
    CountryInfo("🇸🇪", "+46", "Sweden"),
    CountryInfo("🇳🇴", "+47", "Norway"),
    CountryInfo("🇰🇷", "+82", "South Korea"),
    CountryInfo("🇸🇦", "+966", "Saudi Arabia"),
    CountryInfo("🇹🇷", "+90", "Turkey"),
    CountryInfo("🇪🇬", "+20", "Egypt"),
    CountryInfo("🇵🇰", "+92", "Pakistan"),
    CountryInfo("🇧🇩", "+880", "Bangladesh"),
    CountryInfo("🇳🇵", "+977", "Nepal")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(viewModel: RuchikaViewModel) {
    val coroutineScope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf(0) } // 0 = Email, 1 = Phone OTP
    var nameInput by remember { mutableStateOf("") }
    var emailInput by remember { mutableStateOf("") }
    var passwordInput by remember { mutableStateOf("") }
    var phoneInput by remember { mutableStateOf("") }
    var otpInput by remember { mutableStateOf("") }
    
    // OTP Countdown Timer State matching HTML requirement
    var isOtpSent by remember { mutableStateOf(false) }
    var otpTimerSeconds by remember { mutableStateOf(60) }
    var countdownJobActive by remember { mutableStateOf(false) }
    var verificationId by remember { mutableStateOf("") }

    // Dialog & Picker States
    var selectedCountry by remember { mutableStateOf(customCountries[0]) }
    var showCountryDialog by remember { mutableStateOf(false) }
    var countrySearchQuery by remember { mutableStateOf("") }
    var showLanguageDialog by remember { mutableStateOf(false) }

    // Float logo
    val infiniteTransition = rememberInfiniteTransition(label = "floating_logo")
    val floatY by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "offsetY"
    )

    // Trigger timer countdown
    LaunchedEffect(isOtpSent) {
        if (isOtpSent && !countdownJobActive) {
            countdownJobActive = true
            while (otpTimerSeconds > 0) {
                delay(1000L)
                otpTimerSeconds--
            }
            isOtpSent = false
            countdownJobActive = false
            otpTimerSeconds = 60
        }
    }

    val firebaseAuth = remember {
        try {
            FirebaseAuth.getInstance()
        } catch (e: Exception) {
            Log.w("PhoneAuth", "Firebase Auth not linked - sandbox simulated callbacks")
            null
        }
    }

    val context = LocalContext.current
    val gso = remember {
        try {
            GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken("220303587693-56gfeeaophd1sp9lqae6nsg1e943r9gv.apps.googleusercontent.com")
                .requestEmail()
                .build()
        } catch (e: Exception) {
            Log.w("LoginScreen", "Google Services not present")
            null
        }
    }
    val googleSignInClient = remember {
        if (gso != null) {
            try {
                GoogleSignIn.getClient(context, gso)
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
    }

    val signInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        handleGoogleSignInResult(task, viewModel, context)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF060612)), // v9 --bg main background
        contentAlignment = Alignment.Center
    ) {
        // Particle & Grid overlay canvas
        CanvasBackground()

        Box(
            modifier = Modifier
                .fillMaxSize()
                .navigationBarsPadding(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(40.dp))

                // Globe Language selector top right alignment
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFA855F7).copy(alpha = 0.08f))
                            .border(
                                width = 1.dp,
                                color = Color(0xFFA855F7).copy(alpha = 0.3f),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { showLanguageDialog = true }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "🌐 ${viewModel.selectedLanguage.second}",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Lang Dropdown",
                                tint = Color(0xFF22D3EE),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Floating glass-framed logo
                Box(
                    modifier = Modifier
                        .offset(y = floatY.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .border(
                            width = 1.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(Color(0xFFA855F7), Color(0xFF22D3EE))
                            ),
                            shape = RoundedCornerShape(24.dp)
                        )
                        .background(Color(0xFF08071A).copy(alpha = 0.7f))
                        .padding(4.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ruchika_logo),
                        contentDescription = "Ruchika Logo",
                        modifier = Modifier
                            .size(76.dp)
                            .clip(RoundedCornerShape(20.dp)),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Welcome gradient text
                Text(
                    text = "Welcome to RUCHIKA AI",
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.SansSerif,
                    style = TextStyle(
                        brush = Brush.linearGradient(
                            colors = listOf(Color.White, Color(0xFFA855F7), Color(0xFF22D3EE))
                        ),
                        letterSpacing = 1.sp,
                        textAlign = TextAlign.Center
                    )
                )

                // Power Badge Small
                Text(
                    text = "WORLDS MOST POWERFUL AI",
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Light,
                    color = Color(0xFF22D3EE),
                    letterSpacing = 1.5.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(18.dp))

                // GLASS CARD CONTAINER (rgba white 4%, purple border 30%, rounded 24dp)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color.White.copy(alpha = 0.04f)) // rgba white 4%
                        .border(
                            width = 1.dp,
                            color = Color(0xFFA855F7).copy(alpha = 0.30f), // purple border 30%
                            shape = RoundedCornerShape(24.dp)
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        // Tab Switcher (Pill style, active purple gradient)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.Black.copy(alpha = 0.25f))
                                .border(1.dp, Color(0xFF334155).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                .padding(3.dp)
                        ) {
                            // Email tab
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(10.dp))
                                    .then(
                                        if (selectedTab == 0) {
                                            Modifier.background(
                                                brush = Brush.linearGradient(colors = listOf(Color(0xFFA855F7), Color(0xFFEC4899))),
                                                shape = RoundedCornerShape(10.dp)
                                            )
                                        } else {
                                            Modifier.background(
                                                color = Color.Transparent,
                                                shape = RoundedCornerShape(10.dp)
                                            )
                                        }
                                    )
                                    .clickable { selectedTab = 0 },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "📧 Email",
                                    color = if (selectedTab == 0) Color.White else Color.Gray,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            // Phone OTP tab
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(10.dp))
                                    .then(
                                        if (selectedTab == 1) {
                                            Modifier.background(
                                                brush = Brush.linearGradient(colors = listOf(Color(0xFFA855F7), Color(0xFFEC4899))),
                                                shape = RoundedCornerShape(10.dp)
                                            )
                                        } else {
                                            Modifier.background(
                                                color = Color.Transparent,
                                                shape = RoundedCornerShape(10.dp)
                                            )
                                        }
                                    )
                                    .clickable { selectedTab = 1 },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "📱 Phone",
                                    color = if (selectedTab == 1) Color.White else Color.Gray,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        if (selectedTab == 0) {
                            // EMAIL TAB
                            // Name field
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "Your Name",
                                    fontSize = 10.sp,
                                    color = Color(0xFFF1F5F9).copy(alpha = 0.45f),
                                    fontWeight = FontWeight.SemiBold,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                                OutlinedTextField(
                                    value = nameInput,
                                    onValueChange = {
                                        nameInput = it
                                        viewModel.loginNameInput = it
                                    },
                                    placeholder = { Text("E.g. Himanshu", color = Color.Gray, fontSize = 14.sp) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFFA855F7),
                                        unfocusedBorderColor = Color(0xFF334155),
                                        focusedContainerColor = Color.White.copy(alpha = 0.03f),
                                        unfocusedContainerColor = Color.White.copy(alpha = 0.03f)
                                    ),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("name_input")
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Email Field
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "Email Address",
                                    fontSize = 10.sp,
                                    color = Color(0xFFF1F5F9).copy(alpha = 0.45f),
                                    fontWeight = FontWeight.SemiBold,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                                OutlinedTextField(
                                    value = emailInput,
                                    onValueChange = {
                                        emailInput = it
                                        viewModel.loginEmailInput = it
                                    },
                                    placeholder = { Text("you@example.com", color = Color.Gray, fontSize = 14.sp) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFFA855F7),
                                        unfocusedBorderColor = Color(0xFF334155),
                                        focusedContainerColor = Color.White.copy(alpha = 0.03f),
                                        unfocusedContainerColor = Color.White.copy(alpha = 0.03f)
                                    ),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("email_input")
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Password Field
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "Secure Password",
                                    fontSize = 10.sp,
                                    color = Color(0xFFF1F5F9).copy(alpha = 0.45f),
                                    fontWeight = FontWeight.SemiBold,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                                OutlinedTextField(
                                    value = passwordInput,
                                    onValueChange = { passwordInput = it },
                                    placeholder = { Text("••••••••", color = Color.Gray) },
                                    visualTransformation = PasswordVisualTransformation(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Color.White,
                                        unfocusedTextColor = Color.White,
                                        focusedBorderColor = Color(0xFFA855F7),
                                        unfocusedBorderColor = Color(0xFF334155),
                                        focusedContainerColor = Color.White.copy(alpha = 0.03f),
                                        unfocusedContainerColor = Color.White.copy(alpha = 0.03f)
                                    ),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth().testTag("password_input")
                                )
                            }
                        } else {
                            // PHONE TAB (with Country select + phone inputs + OTP countdown + inline Send OTP)
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "Phone Number",
                                    fontSize = 10.sp,
                                    color = Color(0xFFF1F5F9).copy(alpha = 0.45f),
                                    fontWeight = FontWeight.SemiBold,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                                
                                // Phone Row with country select
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(54.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color.White.copy(alpha = 0.03f))
                                        .border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
                                        .clickable { showCountryDialog = true }
                                        .padding(horizontal = 12.dp)
                                ) {
                                    Text(
                                        text = "${selectedCountry.flag}  ${selectedCountry.code}",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Flag Selector",
                                        tint = Color.LightGray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(modifier = Modifier.width(1.dp).fillMaxHeight(0.5f).background(Color(0xFF334155)))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    
                                    Box(
                                        modifier = Modifier.weight(1f),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        androidx.compose.foundation.text.BasicTextField(
                                            value = phoneInput,
                                            onValueChange = {
                                                phoneInput = it
                                                viewModel.loginPhoneInput = it
                                            },
                                            textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                                            decorationBox = { inner ->
                                                if (phoneInput.isEmpty()) {
                                                    Text("Enter phone", color = Color.Gray, fontSize = 14.sp)
                                                }
                                                inner()
                                            },
                                            modifier = Modifier.fillMaxWidth().testTag("phone_input")
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // OTP Code Block (Input + Send button inline)
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "Verification OTP",
                                    fontSize = 10.sp,
                                    color = Color(0xFFF1F5F9).copy(alpha = 0.45f),
                                    fontWeight = FontWeight.SemiBold,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    // OTP Input Wrap
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(54.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .background(Color.White.copy(alpha = 0.03f))
                                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(14.dp))
                                            .padding(horizontal = 12.dp),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        androidx.compose.foundation.text.BasicTextField(
                                            value = otpInput,
                                            onValueChange = { otpInput = it },
                                            textStyle = TextStyle(color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp),
                                            decorationBox = { inner ->
                                                if (otpInput.isEmpty()) {
                                                    Text("6-digit code", color = Color.Gray, fontSize = 14.sp, letterSpacing = 0.2.sp)
                                                }
                                                inner()
                                            },
                                            modifier = Modifier.fillMaxWidth().testTag("otp_input")
                                        )
                                    }

                                    // Send OTP Button Pill (Active purple gradient)
                                    Box(
                                        modifier = Modifier
                                            .height(54.dp)
                                            .clip(RoundedCornerShape(14.dp))
                                            .then(
                                                if (phoneInput.isBlank() || isOtpSent) {
                                                    Modifier.background(
                                                        color = Color.Gray.copy(alpha = 0.3f),
                                                        shape = RoundedCornerShape(14.dp)
                                                    )
                                                } else {
                                                    Modifier.background(
                                                        brush = Brush.linearGradient(colors = listOf(Color(0xFFA855F7), Color(0xFFEC4899))),
                                                        shape = RoundedCornerShape(14.dp)
                                                    )
                                                }
                                            )
                                            .clickable(enabled = phoneInput.isNotBlank() && !isOtpSent) {
                                                val fullNumber = "${selectedCountry.code}$phoneInput"
                                                isOtpSent = true
                                                Toast
                                                    .makeText(context, "OTP Sent! Sim code: 123456 (Sandbox Active)", Toast.LENGTH_SHORT)
                                                    .show()
                                                verificationId = "sandbox_id"
                                            }
                                            .padding(horizontal = 16.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (isOtpSent) " ✓ Sent" else "Send OTP",
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                // Countdown description
                                if (isOtpSent) {
                                    Text(
                                        text = "Resend OTP in ${otpTimerSeconds}s",
                                        color = Color(0xFF22D3EE),
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(top = 6.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // PRIMARY BUTTON full width gradient purple -> pink pill shape glowing shadow
                        Button(
                            onClick = {
                                if (selectedTab == 0) {
                                    if (nameInput.isBlank()) {
                                        Toast.makeText(context, "Please enter your name", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    val emailVal = if (emailInput.isNotBlank()) emailInput else "himanshu@ruchika.app"
                                    viewModel.loginUser(name = nameInput, email = emailVal, phone = "None")
                                } else {
                                    if (phoneInput.isBlank()) {
                                        Toast.makeText(context, "Please enter a valid phone number", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    viewModel.loginUser(
                                        name = "User (${selectedCountry.code}$phoneInput)",
                                        phone = "${selectedCountry.code}$phoneInput"
                                    )
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("submit_button"),
                            shape = RoundedCornerShape(27.dp), // Pill Shape
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            contentPadding = PaddingValues()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.linearGradient(
                                            colors = listOf(Color(0xFFA855F7), Color(0xFFEC4899))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Continue with Ruchika AI  →",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Standard Divider and Social authentication buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.weight(1f).height(1.dp).background(Color.White.copy(alpha = 0.08f)))
                    Text(
                        text = " or continue with ",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                    Box(modifier = Modifier.weight(1f).height(1.dp).background(Color.White.copy(alpha = 0.08f)))
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Social platforms array: Google, Apple, GitHub
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Google
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.025f))
                            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
                            .clickable {
                                try {
                                    val client = googleSignInClient
                                    if (client != null) {
                                        signInLauncher.launch(client.signInIntent)
                                    } else {
                                        viewModel.loginWithGoogle("Himanshu (OAuth)", "himanshu@ruchika.app")
                                    }
                                } catch (e: Exception) {
                                    viewModel.loginWithGoogle("Himanshu (OAuth)", "himanshu@ruchika.app")
                                }
                            }
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🛡️", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Continue with Google Account",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Text(text = "›", color = Color.Gray, fontSize = 18.sp)
                    }

                    // Apple
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.025f))
                            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
                            .clickable {
                                viewModel.loginUser("Apple User", "apple-user@ruchika.app")
                            }
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "🍎", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Continue with Apple ID",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Text(text = "›", color = Color.Gray, fontSize = 18.sp)
                    }

                    // GitHub
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.025f))
                            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(14.dp))
                            .clickable {
                                viewModel.loginUser("Github Guru", "github@ruchika.app")
                            }
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "💻", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Continue with GitHub Code",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Text(text = "›", color = Color.Gray, fontSize = 18.sp)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                
                Text(
                    text = "By continuing you agree to our Terms of Service & Privacy policy",
                    fontSize = 10.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(bottom = 30.dp)
                )
            }
        }

        // Country dialog list searchable
        if (showCountryDialog) {
            AlertDialog(
                onDismissRequest = { showCountryDialog = false },
                containerColor = Color(0xFF08071A),
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showCountryDialog = false }) {
                        Text("Close", color = Color.White)
                    }
                },
                title = { Text("Search Country Code", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                text = {
                    Column(modifier = Modifier.fillMaxWidth().height(360.dp)) {
                        OutlinedTextField(
                            value = countrySearchQuery,
                            onValueChange = { countrySearchQuery = it },
                            placeholder = { Text("E.g. India", color = Color.Gray) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFFA855F7),
                                unfocusedBorderColor = Color(0xFF334155)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        )

                        val list = customCountries.filter {
                            it.name.contains(countrySearchQuery, ignoreCase = true) || it.code.contains(countrySearchQuery)
                        }

                        LazyColumn(modifier = Modifier.weight(1f)) {
                            items(list) { country ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedCountry = country
                                            showCountryDialog = false
                                        }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = country.flag, fontSize = 20.sp)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(text = country.name, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                                    Text(text = country.code, color = Color(0xFF22D3EE), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                                Box(modifier = Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFF0F0E24)))
                            }
                        }
                    }
                }
            )
        }

        // Searchable language portal matching 40+ language list
        if (showLanguageDialog) {
            AlertDialog(
                onDismissRequest = { showLanguageDialog = false },
                containerColor = Color(0xFF08071A),
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showLanguageDialog = false }) {
                        Text("Close", color = Color.White)
                    }
                },
                title = { Text("Select Neural Language", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
                text = {
                    Column(modifier = Modifier.fillMaxWidth().height(360.dp)) {
                        var q by remember { mutableStateOf("") }
                        OutlinedTextField(
                            value = q,
                            onValueChange = { q = it },
                            placeholder = { Text("Search 40+ languages...", color = Color.Gray) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFFA855F7),
                                unfocusedBorderColor = Color(0xFF334155)
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        )

                        val list = viewModel.languages.filter {
                            it.second.contains(q, ignoreCase = true) || it.third.contains(q, ignoreCase = true)
                        }

                        LazyColumn(modifier = Modifier.weight(1f)) {
                            items(list) { opt ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            viewModel.selectedLanguage = opt
                                            showLanguageDialog = false
                                        }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = opt.first, fontSize = 20.sp)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = opt.second, color = Color.White, fontSize = 14.sp)
                                        Text(text = opt.third, color = Color.Gray, fontSize = 11.sp)
                                    }
                                }
                                Box(modifier = Modifier.fillMaxWidth().height(0.5.dp).background(Color(0xFF0F0E24)))
                            }
                        }
                    }
                }
            )
        }
    }
}

fun handleGoogleSignInResult(
    task: Task<GoogleSignInAccount>,
    viewModel: RuchikaViewModel,
    context: android.content.Context
) {
    try {
        val account = task.getResult(ApiException::class.java)
        if (account != null) {
            val name = account.displayName ?: "Google User"
            val email = account.email ?: "google-user@ruchika.app"
            Toast.makeText(context, "Welcome, $name!", Toast.LENGTH_SHORT).show()
            viewModel.loginWithGoogle(name, email)
        } else {
            viewModel.loginWithGoogle("Google Sandbox User", "himanshu@ruchika.app")
        }
    } catch (e: ApiException) {
        val statusCode = e.statusCode
        Log.e("GoogleSignIn", "Google Sign-In failed with status code: $statusCode", e)
        if (statusCode == 10 || statusCode == 12500 || statusCode == 7 || statusCode == 8) {
            viewModel.loginWithGoogle("Himanshu", "himanshu@ruchika.app")
        } else {
            Toast.makeText(context, "Google Sign-In Failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        viewModel.loginWithGoogle("Google User", "himanshu@ruchika.app")
    }
}

private fun findActivity(context: android.content.Context): Activity? {
    var tempContext = context
    while (tempContext is android.content.ContextWrapper) {
        if (tempContext is Activity) {
            return tempContext
        }
        tempContext = tempContext.baseContext
    }
    return tempContext as? Activity
}

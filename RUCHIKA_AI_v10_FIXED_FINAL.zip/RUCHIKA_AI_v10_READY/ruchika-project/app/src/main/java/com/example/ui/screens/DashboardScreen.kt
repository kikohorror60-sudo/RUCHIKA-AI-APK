package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.RuchikaViewModel

@Composable
fun DashboardScreen(
    viewModel: RuchikaViewModel,
    onNavigateToPane: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val chatThreads by viewModel.chatThreads.collectAsState()
    val memoryEntries by viewModel.memoryEntries.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF060612))
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // GREETING HEADER
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Welcome back, ${viewModel.userName} 👋",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Ruchika AI OS Dashboard state monitor",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }

            Box(
                modifier = Modifier
                    .background(Color(0xFF22C55E).copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFF22C55E).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(6.dp).background(Color(0xFF22C55E), CircleShape))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ACTIVE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF22C55E))
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // STATS COUNTERS ROW
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard(
                title = "Conversations",
                value = chatThreads.size.toString(),
                description = "Saved active chat logs",
                icon = "💬",
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Aesthetic Agent",
                value = viewModel.currentAgent.name,
                description = viewModel.currentAgent.description.substringBefore(","),
                icon = "🤖",
                modifier = Modifier.weight(1.5f)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard(
                title = "Learned Memory",
                value = "${memoryEntries.size} preferences",
                description = "Self-extraction elements",
                icon = "🧠",
                modifier = Modifier.weight(1f)
            )
            StatCard(
                title = "Premium Tier",
                value = if (viewModel.isPremiumUser) "GOLD MEMBER" else "GUEST TRAIL",
                description = if (viewModel.isPremiumUser) "Premium Unlimited Key" else "Usage quotas apply",
                icon = "💎",
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // COGNITIVE LOGS METRIC CANVAS DRAWINGS
        Text(
            text = "Cognitive Activity Trends",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFA855F7),
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().height(160.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Total neural transactions", fontSize = 11.sp, color = Color.Gray)
                    Text("Last 24 Hours", fontSize = 10.sp, color = Color(0xFF22D3EE), fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height
                    val points = listOf(0.1f, 0.45f, 0.3f, 0.75f, 0.6f, 0.95f, 0.8f, 0.5f)
                    val step = width / (points.size - 1)

                    val linePath = androidx.compose.ui.graphics.Path()
                    points.forEachIndexed { index, ratio ->
                        val x = index * step
                        val y = height - (ratio * height * 0.8f) - 10f
                        if (index == 0) linePath.moveTo(x, y) else linePath.lineTo(x, y)
                    }

                    drawPath(
                        path = linePath,
                        brush = Brush.horizontalGradient(
                            colors = listOf(Color(0xFFA855F7), Color(0xFFEC4899), Color(0xFF22D3EE))
                        ),
                        style = Stroke(width = 3.dp.toPx())
                    )

                    // Draw circular anchors at max points
                    points.forEachIndexed { index, ratio ->
                        val x = index * step
                        val y = height - (ratio * height * 0.8f) - 10f
                        drawCircle(
                            color = Color(0xFFEC4899),
                            radius = 4.dp.toPx(),
                            center = androidx.compose.ui.geometry.Offset(x, y)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // CHATS QUICK LAUNCH
        Text(
            text = "Navigate to Chat Thread shortcuts",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF22D3EE),
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (chatThreads.isEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.02f)),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "No active conversation threads. Tap '+' in sidebar or header to initialize chat sessions.",
                    color = Color.Gray,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    chatThreads.take(4).forEach { thread ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.selectThread(thread.id)
                                    onNavigateToPane("CHAT")
                                }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .background(Color.White.copy(alpha = 0.06f), shape = CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("💬", fontSize = 14.sp)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = thread.title,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Tap to initialize chat stream",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                            }
                            Icon(
                                imageVector = Icons.Default.Launch,
                                contentDescription = "Launch chat",
                                tint = Color(0xFFEC4899),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        HorizontalDivider(color = Color.White.copy(alpha = 0.05f), modifier = Modifier.padding(vertical = 4.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    description: String,
    icon: String,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, fontSize = 11.sp, color = Color.Gray)
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .background(Color.White.copy(alpha = 0.06f), shape = CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(icon, fontSize = 14.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                value,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                description,
                fontSize = 10.sp,
                color = Color.Gray,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

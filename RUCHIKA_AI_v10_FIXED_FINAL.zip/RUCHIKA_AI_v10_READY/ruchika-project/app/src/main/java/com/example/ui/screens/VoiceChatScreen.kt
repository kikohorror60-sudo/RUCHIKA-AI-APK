package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.ui.theme.*
import com.example.ui.viewmodel.RuchikaViewModel
import com.example.ui.viewmodel.Screen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

enum class VoiceChatState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}

enum class PremiumVoice(val label: String, val pitch: Float, val speed: Float, val info: String) {
    SOPHIA("Sophia", 1.25f, 0.93f, "Soft Cute & Warm"),
    ARIA("Aria", 1.05f, 1.05f, "Premium Assistant"),
    JAMES("James", 0.72f, 0.85f, "Deep Calm voice"),
    ALEX("Alex", 0.90f, 1.00f, "Smart Friendly voice")
}

@Composable
fun VoiceChatScreen(viewModel: RuchikaViewModel) {
    val context = LocalContext.current
    var isMuted by remember { mutableStateOf(false) }
    var currentVoice by remember { mutableStateOf(PremiumVoice.SOPHIA) }
    var voiceState by remember { mutableStateOf(VoiceChatState.IDLE) }
    var voiceStatusText by remember { mutableStateOf("Tap the central orb or microphone below to talk.") }
    var spokenSubtitles by remember { mutableStateOf("") }
    var speedMultiplier by remember { mutableStateOf(1.0f) }

    // Animations for visual richness
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_rings")
    val pulseSize1 by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_ring_1"
    )
    val pulseSize2 by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(2800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_ring_2"
    )

    // Spin animation for Thinking State orbits
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotating_orbits"
    )

    // Speech engines setup
    var tts: TextToSpeech? by remember { mutableStateOf(null) }
    
    val speechRecognizer = remember {
        try {
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                SpeechRecognizer.createSpeechRecognizer(context)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e("VoiceChatScreen", "SpeechRecognizer instance failure", e)
            null
        }
    }

    val speechRecognizerIntent = remember {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().language)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
    }

    // Helper to stop TTS speaking explicitly
    fun stopSpeaking() {
        try {
            if (tts?.isSpeaking == true) {
                tts?.stop()
                Log.d("VoiceChatScreen", "TTS playback interrupted & stopped")
            }
        } catch (e: Exception) {
            Log.e("VoiceChatScreen", "Interruption halt failed", e)
        }
    }

    // Dynamic triggers to toggle or fire listeners
    fun startRecording() {
        if (isMuted) return
        stopSpeaking()
        val audioPermission = ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO)
        if (audioPermission == PackageManager.PERMISSION_GRANTED) {
            try {
                speechRecognizer?.startListening(speechRecognizerIntent)
                voiceState = VoiceChatState.LISTENING
                voiceStatusText = "Listening..."
            } catch (e: Exception) {
                Log.e("VoiceChatScreen", "Failed to start listening", e)
                voiceStatusText = "Microphone failed to start."
                voiceState = VoiceChatState.IDLE
            }
        } else {
            voiceStatusText = "Permit microphone access to speak."
            voiceState = VoiceChatState.IDLE
        }
    }

    fun stopRecording() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
        } catch (e: Exception) {
            Log.e("VoiceChatScreen", "Error stopping voice recognizer", e)
        }
        voiceState = VoiceChatState.IDLE
    }

    fun toggleVoiceState() {
        if (voiceState == VoiceChatState.LISTENING) {
            stopRecording()
        } else {
            startRecording()
        }
    }

    // Link Voice Profiles to Speech Configuration
    fun applyVoiceConfig(engine: TextToSpeech?) {
        try {
            engine?.setPitch(currentVoice.pitch)
            engine?.setSpeechRate(currentVoice.speed * speedMultiplier)
        } catch (e: Exception) {
            Log.e("VoiceChatScreen", "Error binding speech multipliers", e)
        }
    }

    var textPromptInput by remember { mutableStateOf("") }

    fun processVoicePrompt(promptText: String) {
        if (promptText.isBlank()) return
        stopSpeaking()
        spokenSubtitles = promptText
        voiceStatusText = "Ruchika is thinking..."
        voiceState = VoiceChatState.THINKING

        viewModel.viewModelScope.launch {
            // Execute generation with premium proxy setup to deliver ultra-fast responses
            val result = com.example.data.api.GeminiService.generateContent(
                prompt = "$promptText (Deliver a dynamic, friendly, plain conversational reply under 2 concise sentences. Do not use bullets or markdown.)",
                systemInstruction = "You are Ruchika Premium Voice Assistant. Answer in warm, fluid and instant conversational language. Minimize robotic pauses.",
                modelName = "gemini-3.5-flash"
            )
            result.fold(
                onSuccess = { reply ->
                    voiceStatusText = reply
                    spokenSubtitles = reply
                    voiceState = VoiceChatState.SPEAKING
                    applyVoiceConfig(tts)
                    if (!isMuted) {
                        val params = Bundle().apply {
                            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "ruchika_voice_utter")
                        }
                        tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, params, "ruchika_voice_utter")
                    } else {
                        // Muted backup
                        delay(4000)
                        voiceState = VoiceChatState.IDLE
                    }
                },
                onFailure = { err ->
                    val fallback = "I could not reach the server, but I am online and here to listen to you! Let's continue."
                    voiceStatusText = fallback
                    spokenSubtitles = fallback
                    voiceState = VoiceChatState.SPEAKING
                    applyVoiceConfig(tts)
                    if (!isMuted) {
                        tts?.speak(fallback, TextToSpeech.QUEUE_FLUSH, null, "ruchika_voice_utter_fail")
                    } else {
                        delay(2000)
                        voiceState = VoiceChatState.IDLE
                    }
                }
            )
        }
    }

    val recognitionListener = remember {
        object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                stopSpeaking() // Ensure interruption before user speaks
                voiceStatusText = "Microphone active. Say something..."
                spokenSubtitles = ""
            }

            override fun onBeginningOfSpeech() {
                stopSpeaking() // Human-like instant interruption
                voiceState = VoiceChatState.LISTENING
                voiceStatusText = "Acquiring voice..."
            }

            override fun onRmsChanged(rmsdB: Float) {
                viewModel.voiceAmplitude = (rmsdB * 4.5f).coerceIn(10f, 100f)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                voiceState = VoiceChatState.THINKING
                voiceStatusText = "Cognitive processing..."
            }

            override fun onError(error: Int) {
                Log.e("SpeechRecognizer", "Recognizer code error: $error")
                if (voiceState == VoiceChatState.LISTENING) {
                    voiceState = VoiceChatState.IDLE
                    voiceStatusText = "Tap orb or mic to speak again."
                }
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    val promptText = matches[0]
                    processVoicePrompt(promptText)
                } else {
                    voiceState = VoiceChatState.IDLE
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    spokenSubtitles = matches[0]
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    // Initialize TextToSpeech engine with listeners
    DisposableEffect(Unit) {
        val initializedTts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                applyVoiceConfig(tts)
            }
        }

        initializedTts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                voiceState = VoiceChatState.SPEAKING
            }

            override fun onDone(utteranceId: String?) {
                // Return to idle state after speech is completed
                viewModel.viewModelScope.launch {
                    delay(300)
                    voiceState = VoiceChatState.IDLE
                    voiceStatusText = "Ruchika is on standby. Tap mic to talk again."
                }
            }

            override fun onError(utteranceId: String?) {
                voiceState = VoiceChatState.IDLE
            }
        })

        tts = initializedTts
        speechRecognizer?.setRecognitionListener(recognitionListener)

        // Pre-run instant permission checks and start listening immediately to give organic premium UX
        val audioPermission = ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO)
        if (audioPermission == PackageManager.PERMISSION_GRANTED) {
            try {
                speechRecognizer?.startListening(speechRecognizerIntent)
                voiceState = VoiceChatState.LISTENING
                voiceStatusText = "Listening..."
            } catch (e: Exception) {
                Log.e("VoiceChatScreen", "Initial speech failed", e)
            }
        } else {
            voiceStatusText = "Please permit microphone permissions to communicate."
        }

        onDispose {
            initializedTts.stop()
            initializedTts.shutdown()
            try {
                speechRecognizer?.cancel()
                speechRecognizer?.destroy()
            } catch (e: Exception) {
                Log.e("VoiceChatScreen", "Engine release error", e)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF060612)) // Base AMOLED glass container style
    ) {
        // Dynamic Glowing Canvas Aura
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val scaleFactor = if (voiceState == VoiceChatState.LISTENING) {
                viewModel.voiceAmplitude / 45f
            } else {
                1.0f
            }

            // Radial gradient aurors matching premium design lines of RUCHIKA AI OS
            val glowColor = when (voiceState) {
                VoiceChatState.LISTENING -> CyanAccent.copy(alpha = 0.2f)
                VoiceChatState.THINKING -> PurplePrimary.copy(alpha = 0.2f)
                VoiceChatState.SPEAKING -> PinkAccent.copy(alpha = 0.18f)
                VoiceChatState.IDLE -> PurplePrimary.copy(alpha = 0.08f)
            }

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(glowColor, Color.Transparent),
                    center = androidx.compose.ui.geometry.Offset(width / 2f, height * 0.4f),
                    radius = (width * 0.75f) * scaleFactor
                ),
                radius = (width * 0.75f) * scaleFactor,
                center = androidx.compose.ui.geometry.Offset(width / 2f, height * 0.4f)
            )
        }

        // Header controls Section
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, start = 16.dp, end = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(
                onClick = { 
                    stopSpeaking()
                    viewModel.currentScreen = Screen.HOME 
                },
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back to Chat", tint = Color.White)
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "RUCHIKA AI OS",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 15.sp,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "Cognitive Voice Node",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            // Mute trigger button
            IconButton(
                onClick = { 
                    isMuted = !isMuted
                    if (isMuted) stopSpeaking() else startRecording()
                },
                modifier = Modifier
                    .size(48.dp)
                    .background(if (isMuted) ErrorRed.copy(alpha = 0.2f) else Color.Transparent, CircleShape)
            ) {
                Icon(
                    imageVector = if (isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
                    contentDescription = "Mute Volume",
                    tint = if (isMuted) ErrorRed else Color.White
                )
            }
        }

        // Central Orb elements
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 80.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.size(280.dp),
                contentAlignment = Alignment.Center
            ) {
                // Glowing outer wave pulse 1
                if (voiceState != VoiceChatState.IDLE) {
                    Canvas(modifier = Modifier.size(240.dp)) {
                        drawCircle(
                            color = when (voiceState) {
                                VoiceChatState.LISTENING -> Color(0xFF22D3EE).copy(alpha = 0.12f)
                                VoiceChatState.SPEAKING -> Color(0xFFEC4899).copy(alpha = 0.12f)
                                else -> Color(0xFF9061FF).copy(alpha = 0.12f)
                            },
                            radius = (size.width / 2f) * if (voiceState == VoiceChatState.LISTENING) (viewModel.voiceAmplitude / 60f).coerceAtLeast(1f) else pulseSize1,
                            style = Stroke(width = 3.dp.toPx())
                        )
                    }

                    // Floating outer wave pulse 2
                    Canvas(modifier = Modifier.size(240.dp)) {
                        drawCircle(
                            color = when (voiceState) {
                                VoiceChatState.LISTENING -> Color(0xFF22D3EE).copy(alpha = 0.07f)
                                VoiceChatState.SPEAKING -> Color(0xFFEC4899).copy(alpha = 0.07f)
                                else -> Color(0xFF9061FF).copy(alpha = 0.07f)
                            },
                            radius = (size.width / 2f) * if (voiceState == VoiceChatState.LISTENING) (viewModel.voiceAmplitude / 45f).coerceAtLeast(1f) else pulseSize2,
                            style = Stroke(width = 1.5.dp.toPx())
                        )
                    }
                }

                // Inner core ring
                Canvas(modifier = Modifier.size(200.dp)) {
                    val strokeColor = when (voiceState) {
                        VoiceChatState.LISTENING -> Color(0xFF22D3EE)
                        VoiceChatState.THINKING -> Color(0xFFA855F7)
                        VoiceChatState.SPEAKING -> Color(0xFFEC4899)
                        VoiceChatState.IDLE -> Color(0xFF475569)
                    }
                    drawCircle(
                        color = strokeColor.copy(alpha = 0.4f),
                        radius = size.width / 2f,
                        style = Stroke(width = 4.dp.toPx())
                    )
                }

                // Central interactive adaptive Orb
                when (voiceState) {
                    VoiceChatState.IDLE -> {
                        // Standard Logo
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .border(3.dp, Color(0xFFA855F7).copy(alpha = 0.7f), CircleShape)
                                .background(CardSlate)
                                .clickable { startRecording() },
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.ruchika_logo),
                                contentDescription = "Ruchika AI Center",
                                modifier = Modifier
                                    .size(105.dp)
                                    .clip(CircleShape)
                            )
                        }
                    }

                    VoiceChatState.LISTENING -> {
                        // Glowing reactive cyan circle with active microphone icon
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        colors = listOf(Color(0xFF00E5CC), Color(0xFF00BCC6))
                                    )
                                )
                                .clickable { stopRecording() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Active Listening",
                                tint = Color.White,
                                modifier = Modifier.size(44.dp)
                            )
                        }
                    }

                    VoiceChatState.THINKING -> {
                        // Galaxy orbit circles representing active intelligence parsing systems
                        Box(
                            modifier = Modifier.size(110.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val radius = size.width / 2f
                                drawCircle(
                                    color = Color(0xFFA855F7),
                                    radius = 7.dp.toPx(),
                                    center = androidx.compose.ui.geometry.Offset(
                                        x = radius + (radius - 12.dp.toPx()) * kotlin.math.cos(Math.toRadians(rotationAngle.toDouble())).toFloat(),
                                        y = radius + (radius - 12.dp.toPx()) * kotlin.math.sin(Math.toRadians(rotationAngle.toDouble())).toFloat()
                                    )
                                )
                                drawCircle(
                                    color = Color(0xFFEC4899),
                                    radius = 6.dp.toPx(),
                                    center = androidx.compose.ui.geometry.Offset(
                                        x = radius + (radius - 12.dp.toPx()) * kotlin.math.cos(Math.toRadians(rotationAngle.toDouble() + 120.0)).toFloat(),
                                        y = radius + (radius - 12.dp.toPx()) * kotlin.math.sin(Math.toRadians(rotationAngle.toDouble() + 120.0)).toFloat()
                                    )
                                )
                                drawCircle(
                                    color = Color(0xFF22D3EE),
                                    radius = 5.dp.toPx(),
                                    center = androidx.compose.ui.geometry.Offset(
                                        x = radius + (radius - 12.dp.toPx()) * kotlin.math.cos(Math.toRadians(rotationAngle.toDouble() + 240.0)).toFloat(),
                                        y = radius + (radius - 12.dp.toPx()) * kotlin.math.sin(Math.toRadians(rotationAngle.toDouble() + 240.0)).toFloat()
                                    )
                                )
                            }
                        }
                    }

                    VoiceChatState.SPEAKING -> {
                        // Sound waves oscillations spectrum frequency bar animations
                        Row(
                            modifier = Modifier.height(60.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            for (i in 0..6) {
                                val animDelay = i * 150
                                val targetHeight = remember { Animatable(10f) }
                                LaunchedEffect(key1 = voiceState) {
                                    while (true) {
                                        targetHeight.animateTo(
                                            targetValue = (25..60).random().toFloat(),
                                            animationSpec = tween(durationMillis = 300 + (0..100).random(), easing = FastOutSlowInEasing)
                                        )
                                        targetHeight.animateTo(
                                            targetValue = 10f,
                                            animationSpec = tween(durationMillis = 250, easing = LinearOutSlowInEasing)
                                        )
                                    }
                                }
                                Box(
                                    modifier = Modifier
                                        .width(6.dp)
                                        .height(targetHeight.value.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(
                                            Brush.verticalGradient(
                                                colors = listOf(Color(0xFFEC4899), Color(0xFFA855F7))
                                            )
                                        )
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))

            // Real-time Text Status / Subtitle Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 60.dp)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (spokenSubtitles.isNotBlank()) spokenSubtitles else voiceStatusText,
                    fontWeight = FontWeight.Medium,
                    fontSize = 16.sp,
                    color = if (spokenSubtitles.isNotBlank()) Color.White else TextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 24.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Premium Visual Fallback Typing Prompt to test voice feedback on any emulator environment!
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, Color(0xFF0F0E24), RoundedCornerShape(24.dp))
                    .background(Color(0xFF131826).copy(alpha = 0.4f))
                    .padding(start = 16.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = textPromptInput,
                    onValueChange = { textPromptInput = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    decorationBox = { innerTextField ->
                        if (textPromptInput.isEmpty()) {
                            Text(
                                "Or type prompt fallback system...",
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                        }
                        innerTextField()
                    }
                )
                Button(
                    onClick = {
                        if (textPromptInput.isNotBlank()) {
                            processVoicePrompt(textPromptInput)
                            textPromptInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                    modifier = Modifier.height(38.dp)
                ) {
                    Text("Speak", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Premium Voice Profile Selector Grid
            Text(
                text = "Premium Voice Selection",
                fontWeight = FontWeight.SemiBold,
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 11.sp,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PremiumVoice.values().forEach { voice ->
                    val isSelected = currentVoice == voice
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) PurplePrimary.copy(alpha = 0.16f) else Color(0xFF0F0E24).copy(alpha = 0.3f))
                            .border(
                                width = 1.dp,
                                color = if (isSelected) PurplePrimary else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                stopSpeaking()
                                currentVoice = voice
                                applyVoiceConfig(tts)
                                Toast.makeText(context, "${voice.label} Active — ${voice.info}", Toast.LENGTH_SHORT).show()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = voice.label,
                                color = if (isSelected) PurpleLight else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = if (voice == PremiumVoice.SOPHIA || voice == PremiumVoice.SOPHIA) "Female" else "Male",
                                color = TextSecondary,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Sub control speed parameters
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Speech pacing", color = TextSecondary, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0.75f, 1.0f, 1.25f, 1.5f).forEach { pace ->
                        val isSel = speedMultiplier == pace
                        Box(
                            modifier = Modifier
                                .size(44.dp, 32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) PurplePrimary else CardSlate)
                                .clickable {
                                    stopSpeaking()
                                    speedMultiplier = pace
                                    applyVoiceConfig(tts)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${pace}x",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Fixed bottom control trigger bar
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 32.dp)
                .navigationBarsPadding(),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                // Secondary mic activator
                IconButton(
                    onClick = { toggleVoiceState() },
                    modifier = Modifier
                        .size(72.dp)
                        .background(
                            Brush.linearGradient(
                                colors = when (voiceState) {
                                    VoiceChatState.LISTENING -> listOf(Color(0xFF22D3EE), Color(0xFF06B6D4))
                                    VoiceChatState.SPEAKING -> listOf(Color(0xFFEC4899), Color(0xFFA855F7))
                                    else -> listOf(Color(0xFFA855F7), Color(0xFFEC4899))
                                }
                            ),
                            shape = CircleShape
                        )
                ) {
                    Icon(
                        imageVector = if (voiceState == VoiceChatState.LISTENING) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Trigger Speech input",
                        tint = Color.White,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }
        }
    }
}

private fun findActivity(context: android.content.Context): Activity? {
    var tempContext = context
    while (tempContext is android.content.ContextWrapper) {
        if (tempContext is Activity) {
            return tempContext
        }
        tempContext = tempContext.baseContext
    }
    return tempContext as? Activity
}

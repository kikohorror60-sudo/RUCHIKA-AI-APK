package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.RuchikaViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SandboxScreen(
    viewModel: RuchikaViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var codeText by remember {
        mutableStateOf(
            """// Ruchika AI Kotlin-Compose Sandbox Playground
fun main() {
    val greet = "Ruchika AI Interactive Sandbox"
    println(greet)
    
    // Expressive dynamic layout snippet
    val app = createCustomApplet {
        title = "Aesthetic Applet"
        background = "#060612"
        borderRadius = "16px"
    }
}"""
        )
    }

    var consoleLogs by remember { mutableStateOf(listOf("Sandbox Environment Ready ... Input snippet and trigger Run Code.")) }
    var isCompilingCode by remember { mutableStateOf(false) }
    var buildDuration by remember { mutableStateOf("") }
    var runningOutputPreview by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF060612))
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // HEADER
        Text(
            text = "AI Coding Sandbox Workbench",
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = Color.White
        )
        Text(
            text = "Draft, execute and witness quick UI prototype compilations inside an isolated viewport container",
            fontSize = 11.sp,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(18.dp))

        // EDITOR FRAME CARD (GLASS CARD)
        Text(
            text = "Sandbox Editor Canvas",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFA855F7),
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(modifier = Modifier.size(10.dp).background(Color(0xFFEF4444), RoundedCornerShape(5.dp)))
                        Box(modifier = Modifier.size(10.dp).background(Color(0xFFFBBF24), RoundedCornerShape(5.dp)))
                        Box(modifier = Modifier.size(10.dp).background(Color(0xFF10B981), RoundedCornerShape(5.dp)))
                    }
                    Text("main.kt (Kotlin Sandbox)", fontSize = 10.sp, color = Color.Gray, fontFamily = FontFamily.Monospace)
                }

                OutlinedTextField(
                    value = codeText,
                    onValueChange = { codeText = it },
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        color = Color(0xFF22D3EE)
                    ),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFA855F7).copy(alpha = 0.3f),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.1f),
                        focusedTextColor = Color(0xFF22D3EE),
                        unfocusedTextColor = Color(0xFF22D3EE)
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 6,
                    maxLines = 12
                )
            }
        }

        // TRIGGER RUN gradient-purple-pink
        Button(
            onClick = {
                isCompilingCode = true
                buildDuration = ""
                runningOutputPreview = false
                consoleLogs = listOf("[SYSTEM] Starting compiler pipeline ...", "[SYSTEM] Resolving imports and dependencies ...")
                coroutineScope.launch {
                    delay(800)
                    consoleLogs = consoleLogs + "[COMPILER] Syncing Kotlin Runtime components ..."
                    delay(700)
                    consoleLogs = consoleLogs + "[LINKER] Linking Compose UI engine layout trees ..."
                    delay(600)
                    isCompilingCode = false
                    buildDuration = "480ms"
                    consoleLogs = consoleLogs + "[SUCCESS] Compilation completed successfully in 0.48 seconds."
                    consoleLogs = consoleLogs + "Output block: \n\"Ruchika AI Interactive Sandbox\" executed"
                    runningOutputPreview = true
                    Toast.makeText(context, "Draft executed with zero errors!", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .padding(bottom = 16.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = PaddingValues()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFFA855F7), Color(0xFFEC4899))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (isCompilingCode) "Spinning Compiler... ⚡" else "Compile & Execute Craft Code ⚙️",
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 13.sp
                )
            }
        }

        // OUTPUT CONSOLE LOG GLASS CARD
        Text(
            text = "Compiler Diagnostics Output Console",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFEC4899),
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.4f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("stdout log", fontSize = 10.sp, color = Color.Gray, fontFamily = FontFamily.Monospace)
                    if (buildDuration.isNotEmpty()) {
                        Text("Duration: $buildDuration", fontSize = 10.sp, color = Color(0xFF22C55E), fontWeight = FontWeight.Bold)
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                ) {
                    val terminalFont = FontFamily.Monospace
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        consoleLogs.forEach { log ->
                            val color = when {
                                log.startsWith("[SUCCESS]") || log.contains("executed") -> Color(0xFF22C55E)
                                log.startsWith("[SYSTEM]") -> Color(0xFF22D3EE)
                                log.startsWith("[COMPILER]") || log.startsWith("[LINKER]") -> Color(0xFFFBBF24)
                                else -> Color.LightGray.copy(alpha = 0.8f)
                            }
                            Text(log, fontSize = 10.sp, color = color, fontFamily = terminalFont)
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }
            }
        }

        // EXPERIMENTAL PREVIEW IF SUCCESS
        AnimatedVisibility(
            visible = runningOutputPreview,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Column {
                Text(
                    text = "Live Simulated Applet Viewport",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF22C55E),
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.04f)),
                    border = BorderStroke(1.dp, Color(0xFF22C55E).copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                "COMPILATION SUCCESSFUL",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF22C55E)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "Previewing: Aesthetic Applet",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Render background is aligned to #060612",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }
        }
    }
}

package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.RuchikaViewModel

@Composable
fun OnboardingScreen(viewModel: RuchikaViewModel) {
    var currentStep by remember { mutableStateOf(0) } // 0: Welcome & Language, 1: Choose Agent, 2: System Setup

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF060612)) // Dark #060612 background
    ) {
        // Aesthetic ambient drawing
        CanvasBackground()

        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Steps indicator
            Text(
                text = "STEP ${currentStep + 1} OF 3",
                color = Color(0xFF22D3EE),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )

            // Skip Button
            Text(
                text = "Skip",
                color = Color.White.copy(alpha = 0.5f),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier
                    .clickable { viewModel.completeOnboarding() }
                    .padding(8.dp)
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 80.dp, bottom = 100.dp, start = 24.dp, end = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // STEP 0: WELCOME & NEURAL LANGUAGE MODEL
            if (currentStep == 0) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Spacer(modifier = Modifier.height(20.dp))
                    // Illustration card
                    Box(
                        modifier = Modifier
                            .size(140.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(Color(0xFFA855F7).copy(alpha = 0.2f), Color.Transparent)
                                )
                            )
                            .border(1.dp, Color(0xFFA855F7).copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🌐", fontSize = 60.sp)
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "Initialize Your Neural Language",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Customize the default vocabulary dialect and instruction context model for Ruchika AI integration.",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.45f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp, bottom = 24.dp),
                        lineHeight = 18.sp
                    )

                    // Language list horizontal row
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(viewModel.languages) { lang ->
                            val isSelected = viewModel.selectedLanguage == lang
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .then(
                                        if (isSelected) {
                                            Modifier.background(
                                                brush = Brush.linearGradient(colors = listOf(Color(0xFFA855F7), Color(0xFFEC4899))),
                                                shape = RoundedCornerShape(20.dp)
                                            )
                                        } else {
                                            Modifier.background(
                                                color = Color.White.copy(alpha = 0.04f),
                                                shape = RoundedCornerShape(20.dp)
                                            )
                                        }
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) Color.White.copy(alpha = 0.3f) else Color.White.copy(alpha = 0.07f),
                                        shape = RoundedCornerShape(20.dp)
                                    )
                                    .clickable { viewModel.selectedLanguage = lang }
                                    .padding(horizontal = 16.dp, vertical = 10.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = lang.first, fontSize = 16.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = lang.second, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // STEP 1: CHOOSE AI AGENT PERSONALITY
            if (currentStep == 1) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(Color(0xFF22D3EE).copy(alpha = 0.2f), Color.Transparent)
                                )
                            )
                            .border(1.dp, Color(0xFF22D3EE).copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🤖", fontSize = 42.sp)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Choose Initial Agent",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Each agent has deep specialization, vocabulary presets, and distinctive chat behaviors.",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.45f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                    )

                    // Vertical Grid for 8 agents
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(viewModel.agents) { agent ->
                            val isSelected = viewModel.currentAgent.id == agent.id
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(
                                        if (isSelected) Color(0xFFA855F7).copy(alpha = 0.12f) else Color.White.copy(alpha = 0.04f)
                                    )
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) Color(0xFFA855F7) else Color.White.copy(alpha = 0.07f),
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                    .clickable { viewModel.selectAgent(agent) }
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(text = agent.emoji, fontSize = 20.sp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = agent.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = agent.description,
                                        color = Color.Gray,
                                        fontSize = 10.sp,
                                        lineHeight = 13.sp,
                                        maxLines = 2
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // STEP 2: FINALIZE PREFERENCES
            if (currentStep == 2) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Spacer(modifier = Modifier.height(20.dp))
                    Box(
                        modifier = Modifier
                            .size(130.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(Color(0xFFEC4899).copy(alpha = 0.2f), Color.Transparent)
                                )
                            )
                            .border(1.dp, Color(0xFFEC4899).copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("✨", fontSize = 56.sp)
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        text = "Customize System Parameters",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Configure visual background engine features, dynamic live internet search logic, and cognitive memories.",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.45f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp, bottom = 24.dp),
                        lineHeight = 18.sp
                    )

                    // Options Card Lists
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White.copy(alpha = 0.04f))
                                .border(1.dp, Color.White.copy(alpha = 0.07f), RoundedCornerShape(16.dp))
                                .padding(14.dp)
                        ) {
                            Text("🌊", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Dynamic Animated Wallpaper", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("Renders smooth particle canvas loops", color = Color.Gray, fontSize = 10.sp)
                            }
                            Switch(
                                checked = true,
                                onCheckedChange = {},
                                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFFA855F7))
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.White.copy(alpha = 0.04f))
                                .border(1.dp, Color.White.copy(alpha = 0.07f), RoundedCornerShape(16.dp))
                                .padding(14.dp)
                        ) {
                            Text("🌐", fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Live Internet Lookup Engine", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("Synthesizes web articles in real-time", color = Color.Gray, fontSize = 10.sp)
                            }
                            Switch(
                                checked = viewModel.isWebSearchEnabled,
                                onCheckedChange = { viewModel.isWebSearchEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFFA855F7))
                            )
                        }
                    }
                }
            }

            // DOTS INDICATOR AND WORKSPACE FLOWS
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                for (i in 0..2) {
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .size(width = if (i == currentStep) 16.dp else 6.dp, height = 6.dp)
                            .clip(CircleShape)
                            .background(if (i == currentStep) Color(0xFFA855F7) else Color.White.copy(alpha = 0.2f))
                    )
                }
            }
        }

        // BOTTOM BACK / NEXT PAIR BUTTONS
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(24.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (currentStep > 0) {
                Box(
                    modifier = Modifier
                        .weight(0.4f)
                        .height(52.dp)
                        .clip(RoundedCornerShape(26.dp))
                        .background(Color.White.copy(alpha = 0.04f))
                        .border(1.dp, Color.White.copy(alpha = 0.07f), RoundedCornerShape(26.dp))
                        .clickable { currentStep-- },
                    contentAlignment = Alignment.Center
                ) {
                    Text("Previous", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(52.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFFA855F7), Color(0xFFEC4899))
                        )
                    )
                    .clickable {
                        if (currentStep < 2) {
                            currentStep++
                        } else {
                            viewModel.completeOnboarding()
                        }
                    }
                    .testTag("submit_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (currentStep == 2) "Get Started 🚀" else "Continue  →",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

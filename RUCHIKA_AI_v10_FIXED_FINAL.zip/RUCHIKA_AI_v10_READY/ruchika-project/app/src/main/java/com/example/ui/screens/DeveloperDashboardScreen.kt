package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.RuchikaViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun DeveloperDashboardScreen(
    viewModel: RuchikaViewModel,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val coroutineScope = rememberCoroutineScope()

    var isVerifyingLogs by remember { mutableStateOf(false) }
    var latencyStatus by remember { mutableStateOf("Test Latency") }
    var pingValue by remember { mutableStateOf("-") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF060612))
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // TOP LOGS HEADER
        Text(
            text = "Intelligent Developer Command Room",
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = Color.White
        )
        Text(
            text = "Real-time SQL diagnostics, system registers, Git controls, & telemetry logs",
            fontSize = 11.sp,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(18.dp))

        // TELEMETRY BARS
        Text(
            text = "Hardware Telemetry Stream",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFA855F7),
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // CPU Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("CPU Allocation Sim", fontSize = 11.sp, color = Color.White)
                    Text("14.5% Active (8 Cores)", fontSize = 11.sp, color = Color(0xFF22D3EE), fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { 0.145f },
                    color = Color(0xFF22D3EE),
                    trackColor = Color.White.copy(alpha = 0.08f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )

                Spacer(modifier = Modifier.height(14.dp))

                // RAM Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Heap Sandbox Limits", fontSize = 11.sp, color = Color.White)
                    Text("184 MB / 512 MB Allowed", fontSize = 11.sp, color = Color(0xFFEC4899), fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { 0.359f },
                    color = Color(0xFFEC4899),
                    trackColor = Color.White.copy(alpha = 0.08f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                )
            }
        }

        // DATABASE DIAGNOSTICS & LOGS
        Text(
            text = "Room SQLite Database Registers & Logs",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF22D3EE),
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Active Tables Map", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("chat_message · chat_thread · memory_entry", fontSize = 9.sp, color = Color.Gray)
                    }
                    Button(
                        onClick = {
                            isVerifyingLogs = true
                            coroutineScope.launch {
                                delay(900)
                                isVerifyingLogs = false
                                Toast.makeText(context, "Full index health: 100% (Pruned 0 dead leaf nodes)", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22D3EE)),
                        shape = RoundedCornerShape(8.dp),
                        enabled = !isVerifyingLogs,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text(if (isVerifyingLogs) "Checking..." else "Double Check", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Query Console Mock log window
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(84.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.40f))
                        .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    val terminalFont = FontFamily.Monospace
                    Column {
                        Text("[ROOM REGISTERS] PRAGMA foreign_keys = ON; successfully synced.", fontSize = 9.sp, color = Color(0xFF22C55E), fontFamily = terminalFont)
                        Text("[ROOM REGISTERS] SELECT * FROM chat_thread ORDER BY lastActiveTime DESC limit 10", fontSize = 9.sp, color = Color.White.copy(alpha = 0.8f), fontFamily = terminalFont)
                        Text("[ROOM REGISTERS] SELECT COUNT(*) FROM chat_message WHERE isUser = 0", fontSize = 9.sp, color = Color.White.copy(alpha = 0.8f), fontFamily = terminalFont)
                        Text("[ROOM REGISTERS] 0 indexes missing · vacuum operations ready.", fontSize = 9.sp, color = Color(0xFFFBBF24), fontFamily = terminalFont)
                    }
                }
            }
        }

        // FIREBASE CLOUD CONNECTIVITY
        Text(
            text = "Firebase Cloud Server Latency Tunnels",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFFBBF24),
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Active Endpoint Core Connection", fontSize = 11.sp, color = Color.White)
                        Text("Client Socket Node Status: ESTABLISHED", fontSize = 9.sp, color = Color(0xFF22C55E), fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            latencyStatus = "Pinging..."
                            coroutineScope.launch {
                                delay(700)
                                val randomPing = (12..48).random()
                                pingValue = "$randomPing ms"
                                latencyStatus = "Ping Complete"
                                delay(1500)
                                latencyStatus = "Test Latency"
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFBBF24)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text(latencyStatus, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Connection Latency:", fontSize = 11.sp, color = Color.Gray)
                    Text(pingValue, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        // GIT REMOTE CODE REPOS (CONSOLE PRECISE TO HTML CODE)
        Text(
            text = "Git Remote System Repository Controls",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFEC4899),
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f)),
            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Target Repository Sync Node", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Target Remote: github.com/kikohorror60-sudo/RUCHIKA-AI-", fontSize = 10.sp, color = Color.Gray)
                    }

                    Box(
                        modifier = Modifier
                            .background(Color(0xFFEC4899).copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                            .border(1.dp, Color(0xFFEC4899).copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .clickable {
                                clipboardManager.setText(
                                    AnnotatedString(
                                        "git init\ngit add .\ngit commit -m \"Ruchika AI - Final Complete Version\"\ngit remote add origin https://github.com/kikohorror60-sudo/RUCHIKA-AI-.git\ngit push -u origin main"
                                    )
                                )
                                Toast.makeText(context, "Git command block copied!", Toast.LENGTH_SHORT).show()
                            }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("Copy Script", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEC4899))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.5f))
                        .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    val terminalFont = FontFamily.Monospace
                    Column {
                        Text("git init", fontSize = 11.sp, color = Color(0xFF22D3EE), fontFamily = terminalFont)
                        Text("git add .", fontSize = 11.sp, color = Color(0xFF22D3EE), fontFamily = terminalFont)
                        Text("git commit -m \"Ruchika AI - Final Complete Version\"", fontSize = 11.sp, color = Color(0xFF22D3EE), fontFamily = terminalFont)
                        Text("git remote add origin https://github.com/kikohorror60-sudo/RUCHIKA-AI-.git", fontSize = 11.sp, color = Color(0xFFEC4899), fontFamily = terminalFont)
                        Text("git push -u origin main", fontSize = 11.sp, color = Color(0xFF22C55E), fontFamily = terminalFont)
                    }
                }
            }
        }
    }
}

package com.example.ui.theme

import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary        = PurplePrimary,
    secondary      = PinkAccent,
    tertiary       = CyanAccent,
    background     = DeepSpaceBlue,
    surface        = BgSecondary,
    surfaceVariant = CardSlate,
    onPrimary      = TextPrimary,
    onSecondary    = TextPrimary,
    onTertiary     = TextPrimary,
    onBackground   = TextPrimary,
    onSurface      = TextPrimary,
    outline        = BorderSubtle,
    outlineVariant = BorderPurple,
    error          = ErrorRed,
)

private val LightColorScheme = lightColorScheme(
    primary    = PurplePrimary,
    secondary  = PurpleDark,
    tertiary   = PinkAccent,
    background = LightBackground,
    surface    = LightCard,
    onPrimary  = LightText,
    onBackground = LightText,
    onSurface  = LightText,
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Always dark — AMOLED neon theme
    dynamicColor: Boolean = false, // Disabled: keep exact brand palette
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme,
        typography  = Typography,
        content     = content
    )
}

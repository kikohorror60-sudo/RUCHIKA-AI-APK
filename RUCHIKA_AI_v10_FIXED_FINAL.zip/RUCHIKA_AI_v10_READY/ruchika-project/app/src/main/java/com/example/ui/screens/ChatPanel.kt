package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.ProjectBuildState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatPanel(
    state: ProjectBuildState,
    onPromptSubmitted: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var promptInput by remember { mutableStateOf("") }
    val suggestionChips = listOf(
        "Build a Calculator App",
        "Add a beautiful dark slate theme",
        "Design an interactive chat workspace",
        "Implement a persistent cache database"
    )

    Card(
        modifier = modifier
            .fillMaxHeight()
            .border(1.dp, Color(0xFF0F0E24), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08071A).copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Infinite Pulsate Dot animation
                val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                val alpha by infiniteTransition.animateFloat(
                    initialValue = 0.3f,
                    targetValue = 1.0f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1000, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "alpha"
                )

                val pulseColor = if (state.isBuilding) Color(0xFF10B981) else Color(0xFFA855F7)
                
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(pulseColor.copy(alpha = alpha))
                        .border(1.5.dp, pulseColor, CircleShape)
                )

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = "AI OS Builder Engine",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(14.dp))
            Divider(color = Color(0xFF334155), thickness = 0.5.dp)

            // Chat & Log content view
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            AIChatBubble(
                                text = "Welcome to RUCHIKA OS Integrated Workspace. Choose or outline what kind of modules you want to build and let Gemini compile them instantly."
                            )
                        }

                        if (state.files.isNotEmpty()) {
                            item {
                                UserChatBubble(text = "Construct complete files for ${state.projectName}")
                            }
                            item {
                                AIChatBubble(text = "Compiler completed. Realtime Workspace ready for inspection. Touch any files in left tree hierarchy to examine lines or download Zip.")
                            }
                        }
                    }

                    // Prompt chips helper
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        items(suggestionChips) { chipText ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(99.dp))
                                    .background(Color(0xFF0F0E24))
                                    .clickable {
                                        onPromptSubmitted(chipText)
                                    }
                                    .padding(horizontal = 14.dp, vertical = 6.dp)
                            ) {
                                Text(chipText, fontSize = 11.sp, color = Color(0xFFF1F5F9))
                            }
                        }
                    }
                }
            }

            // Bottom Prompt Inputs
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .border(1.dp, Color(0xFF0F0E24), RoundedCornerShape(26.dp))
                    .background(Color(0xFF08071A))
                    .padding(start = 16.dp, end = 4.dp)
            ) {
                OutlinedTextField(
                    value = promptInput,
                    onValueChange = { promptInput = it },
                    placeholder = { Text("What would you like to build...", color = Color.Gray, fontSize = 13.sp) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = {
                        if (promptInput.isNotBlank()) {
                            onPromptSubmitted(promptInput)
                            promptInput = ""
                        }
                    })
                )

                IconButton(
                    onClick = {
                        promptInput = "Build a complete real-time messaging application"
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color(0xFF0F0E24), CircleShape)
                ) {
                    Icon(Icons.Default.Mic, contentDescription = "Voice", tint = Color.LightGray, modifier = Modifier.size(16.dp))
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = {
                        if (promptInput.isNotBlank()) {
                            onPromptSubmitted(promptInput)
                            promptInput = ""
                        }
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFFA855F7), Color(0xFFEC4899))
                            ),
                            CircleShape
                        )
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Send Prompt", tint = Color.White, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

@Composable
fun AIChatBubble(text: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F0E24).copy(alpha = 0.5f)),
            shape = RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp),
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Text(
                text = text,
                color = Color(0xFFF1F5F9),
                fontSize = 13.sp,
                lineHeight = 18.sp,
                modifier = Modifier.padding(12.dp)
            )
        }
    }
}

@Composable
fun UserChatBubble(text: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
    ) {
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp))
                .background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xFFA855F7), Color(0xFFEC4899))
                    )
                )
                .padding(12.dp)
        ) {
            Text(
                text = text,
                color = Color.White,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
        }
    }
}

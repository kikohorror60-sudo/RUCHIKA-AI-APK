package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.BuildLogEntry
import com.example.ui.viewmodel.LogType
import com.example.ui.viewmodel.ProjectBuildState

@Composable
fun BuildLogPanel(
    state: ProjectBuildState,
    onFileTriggered: (String) -> Unit,
    onClearLogs: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    // Auto scroll to latest logs
    LaunchedEffect(state.logs.size) {
        if (state.logs.isNotEmpty()) {
            listState.animateScrollToItem(state.logs.size - 1)
        }
    }

    Card(
        modifier = modifier
            .fillMaxHeight()
            .border(1.dp, Color(0xFF0F0E24), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF08071A).copy(alpha = 0.6f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Sandbox Build Log",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = if (state.isBuilding) "Compiling modules..." else "Idle Node",
                        fontSize = 11.sp,
                        color = if (state.isBuilding) Color(0xFF10B981) else Color.Gray
                    )
                }

                if (state.isBuilding) {
                    CircularProgressIndicator(
                        strokeWidth = 2.dp,
                        color = Color(0xFFA855F7),
                        modifier = Modifier.size(16.dp)
                    )
                } else {
                    Text(
                        text = "Clear",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        modifier = Modifier
                            .clickable { onClearLogs() }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Divider(color = Color(0xFF334155), thickness = 0.5.dp)
            Spacer(modifier = Modifier.height(10.dp))

            if (state.logs.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No logs. Trigger prompt output compilation to view sandbox checks.",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            } else {
                LazyColumn(
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(state.logs) { entry ->
                        AnimatedLogItem(
                            entry = entry,
                            onFileClick = { fileName ->
                                val target = state.files.find { it.name == fileName }
                                if (target != null) {
                                    onFileTriggered(target.id)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AnimatedLogItem(
    entry: BuildLogEntry,
    onFileClick: (String) -> Unit
) {
    val (typeLabel, iconColor, textColor) = when (entry.type) {
        LogType.INFO -> Triple("INFO", Color(0xFF22D3EE), Color(0xFF22D3EE))       // Cyan
        LogType.CREATE -> Triple("CREATE", Color(0xFFF59E0B), Color(0xFFFFB03A))   // Amber
        LogType.SUCCESS -> Triple("SUCCESS", Color(0xFF10B981), Color(0xFF4ADE80)) // Green
        LogType.ERROR -> Triple("ERROR", Color(0xFFEF4444), Color(0xFFF87171))     // Red
        LogType.SYSTEM -> Triple("SYSTEM", Color.Gray, Color.LightGray)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF131B2E).copy(alpha = 0.3f))
            .padding(8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Severity indicator bubble tag
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(iconColor.copy(alpha = 0.15f))
                    .border(0.5.dp, iconColor.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = typeLabel,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = iconColor,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = if (entry.timestamp == "RESTORED" || entry.timestamp == "SUCCESS") "" else "${entry.timestamp} ",
                fontSize = 11.sp,
                color = Color.Gray,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.weight(1f))

            if (!entry.fileName.isNullOrEmpty()) {
                Text(
                    text = entry.fileName,
                    fontSize = 11.sp,
                    color = Color(0xFFA78BFA),
                    fontFamily = FontFamily.Monospace,
                    textDecoration = TextDecoration.Underline,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .clickable { onFileClick(entry.fileName) }
                        .padding(horizontal = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = entry.message,
            fontSize = 11.sp,
            color = textColor,
            fontFamily = FontFamily.Monospace,
            lineHeight = 15.sp,
            modifier = Modifier.padding(horizontal = 2.dp)
        )
    }
}

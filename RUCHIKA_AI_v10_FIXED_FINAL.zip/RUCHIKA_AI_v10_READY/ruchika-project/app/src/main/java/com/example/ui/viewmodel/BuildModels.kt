package com.example.ui.viewmodel

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

enum class FileNodeType {
    FOLDER, FILE
}

enum class FileLanguage {
    KOTLIN, XML, GRADLE, JSON, MD, OTHER
}

data class FileNode(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val path: String,
    val type: FileNodeType,
    var content: String = "",
    val language: FileLanguage = FileLanguage.OTHER,
    val createdAt: Long = System.currentTimeMillis(),
    var isModified: Boolean = false
)

enum class LogType {
    INFO, CREATE, SUCCESS, ERROR, SYSTEM
}

data class BuildLogEntry(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: String,
    val type: LogType,
    val message: String,
    val fileName: String? = null
)

@Entity(tableName = "build_history")
data class BuildHistory(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val projectName: String,
    val prompt: String,
    val fileCount: Int,
    val codeLinesCount: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val filesJson: String
)

data class ProjectBuildState(
    val projectName: String = "My Application",
    val files: List<FileNode> = emptyList(),
    val logs: List<BuildLogEntry> = emptyList(),
    val isBuilding: Boolean = false,
    val currentTask: String = "",
    val totalFiles: Int = 0,
    val completedFiles: Int = 0,
    val buildTimeSeconds: Int = 0
)
